package ch07.lambda_streams.solutions;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex04_NamesCount
{
    private Ex04_NamesCount()
    {
    }

    static Map<String, Long> valueCount(final List<String> values)
    {
        final Map<String, Long> valueToCount = new TreeMap<>();

        values.forEach(value -> {
            valueToCount.putIfAbsent(value, 0L);
            valueToCount.computeIfPresent(value, (orig, count) -> ++count);
        });
        return valueToCount;
    }

    static Map<String, Long> valueCountV2(final List<String> values)
    {
        return values.stream().collect(Collectors.groupingBy(name -> name, Collectors.counting()));
    }

    public static void main(String[] args)
    {
        var names = List.of("Tim", "Tom", "Mike", "Jim", "Tim", "Mike", "James", "Mike");

        System.out.println(valueCount(names));
        System.out.println(valueCountV2(names));       
    }
}
