package ch07.lambda_streams.solutions;

import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex02_PrimeFiltering
{
    public static void main(String[] args)
    {
        var primes = List.of(2, 3, 5, 7, 11, 13, 17, 19, 23, 29);
        
        Function<Integer, Integer> qubic = x -> (int)Math.pow(x, 3);
        Predicate<Integer> inRange = x -> x > 20 && x < 500;
        
        System.out.println(primes.stream().map(qubic).filter(inRange).toList());
    }
}
