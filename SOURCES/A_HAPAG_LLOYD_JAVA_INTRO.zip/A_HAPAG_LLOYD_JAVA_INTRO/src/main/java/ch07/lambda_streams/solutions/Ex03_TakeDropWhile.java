package ch07.lambda_streams.solutions;

import java.util.List;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex03_TakeDropWhile
{
    public static void main(String[] args)
    {
        var data = List.of("x", "y", "<START>", "FIRST", "SECOND", "<END>", "x", "y");
        
        List<String> extractedPayload = data.stream().
             dropWhile(str -> !str.equals("<START>")).
             skip(1).
             takeWhile(str -> !str.equals("<END>")).toList();

        System.out.println(extractedPayload);
    }
}
