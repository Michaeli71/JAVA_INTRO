package ch07.lambda_streams.solutions;

import java.util.List;
import java.util.function.Predicate;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex01_LambdaNameFilter
{
    public static void main(String[] args)
    {
        var sampleNames = List.of("TIM", "TOM", "MIKE", "JOHN", "MICHAEL", "STEFAN");
        
        // a)
        Predicate<String> hasEvenLength = str -> str.length() % 2 == 0;
        Predicate<String> hasOddLength = hasEvenLength.negate();
        
        sampleNames.stream().filter(hasEvenLength).forEach(System.out::println);
        sampleNames.stream().filter(hasOddLength).forEach(System.out::println);
        
        // b)
        System.out.println(sampleNames.stream().map(str -> str.length()).toList());
    }
}
