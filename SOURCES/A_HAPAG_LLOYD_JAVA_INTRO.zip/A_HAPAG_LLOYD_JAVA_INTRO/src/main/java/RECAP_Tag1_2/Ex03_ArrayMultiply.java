package RECAP_Tag1_2;

/**
* Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
*
* @author Michael Inden
*
* Copyright 2021 by Michael Inden
*/
public class Ex03_ArrayMultiply
{
    public static void main(String[] args)
    {
        int[] values = { 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21};
        
        for (int i = 0; i < values.length; i+=3)
            System.out.println(values[i]);
    }
}
