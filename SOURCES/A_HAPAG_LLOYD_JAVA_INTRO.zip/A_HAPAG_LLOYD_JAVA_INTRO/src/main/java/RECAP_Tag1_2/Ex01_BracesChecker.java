package RECAP_Tag1_2;

/**
* Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
*
* @author Michael Inden
*
* Copyright 2021 by Michael Inden
*/
public class Ex01_BracesChecker 
{
	boolean checkBraces(final String input) 
	{
		int openingCount = 0;

		for (char ch : input.toCharArray()) 
		{
			if (ch == '(') 
			{
				openingCount++;
			} 
			else if (ch == ')') 
			{
				openingCount--;
				if (openingCount < 0)
					return false;
			}
		}
		return openingCount == 0;
	}
}
