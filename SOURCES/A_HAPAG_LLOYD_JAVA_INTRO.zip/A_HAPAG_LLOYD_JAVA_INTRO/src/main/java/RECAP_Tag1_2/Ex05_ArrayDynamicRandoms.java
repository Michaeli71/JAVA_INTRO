package RECAP_Tag1_2;

import java.util.Arrays;

/**
* Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
*
* @author Michael Inden
*
* Copyright 2021 by Michael Inden
*/
public class Ex05_ArrayDynamicRandoms
{
    public static void main(String[] args)
    {
        int[] values1 = createRandomArray(10);
        int[] values2 = createRandomArray(20);
        int[] values3 = createRandomArray(30);
        
        System.out.println("values1: " + Arrays.toString(values1));
        System.out.println("values2: " + Arrays.toString(values2));
        System.out.println("values3: " + Arrays.toString(values3));
        
        Arrays.sort(values1);
        System.out.println("sorted values1: " + Arrays.toString(values1));
    }
    
    static int[] createRandomArray(int size)
    {
        int[] result = new int[size];
        
        for (int i = 0; i < size; i++)
        {
            result[i] = (int) (Math.random() * 100);
        }
        
        return result;
    }
}
