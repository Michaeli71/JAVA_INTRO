package RECAP_Tag1_2;

import java.util.Arrays;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class MobCoding_MinimumDistance
{
    public static void main(String[] args)
    {
        int[] values = { 1,7,2,9,5,4,8,6 };

        // Schritt 1: Distanzen ermitteln
        int[] distances = calcDistances(values);
        System.out.println(Arrays.toString(distances));
        
        // Schritt 2: Finde minimale Distanz
        // Hier finden wir, dass wir absolute Distnaz benötigen
        // Arrays.sort(distances);
        // System.out.println(distances[0]);
        
        // Schritt 2b: Finde Position der minimalen Distanz?
        int posOfMin = findMinPos(distances);
        System.out.println(posOfMin);
        
        
        int[] values1 = {4, 8, 6, 1, 2, 9, 4};
        System.out.println(findMinPos(calcDistances(values1)));
        
        int[] values2 = {4, 11, 6, 1, 5, 7, 2, 9, 4};
        System.out.println(findMinPos(calcDistances(values2)));
    }

    private static int findMinPos(int[] values)
    {
        // Fehlerbehandlung leeres Array
        //if (values.length == 0)
        //    throw new IllegalArgumentException("empyt data");
        if (values.length == 0)
            return -1;
                
        int min = values[0];
        int minPos = 0;
        
        for (int i = 1; i < values.length; i++)
        {
            if (values[i] < min)
            {
                min = values[i];
                minPos = i;
            }
        }
        return minPos;
    }

    private static int[] calcDistances(int[] values)
    {
        int[] distances = new int[values.length - 1];
        
        for (int i = 0; i < values.length - 1; i++)
        {
            // Korrektur 1: nutze Math.abs()
            int distance = Math.abs(values[i] - values[i + 1]);
            distances[i] = distance;
        }
        
        return distances;
    }
}
