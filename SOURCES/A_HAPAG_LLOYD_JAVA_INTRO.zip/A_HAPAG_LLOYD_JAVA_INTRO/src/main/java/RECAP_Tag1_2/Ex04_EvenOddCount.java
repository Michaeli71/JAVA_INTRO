package RECAP_Tag1_2;

/**
* Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
*
* @author Michael Inden
*
* Copyright 2021 by Michael Inden
*/
public class Ex04_EvenOddCount
{
    public static void main(String[] args)
    {
        int[] values = { 2,3,5,8,13,21,34,55,89,144 };
        
        int oddCount = countOdds(values);        
        int evenCount = values.length - oddCount;
        System.out.println("#odd: " + oddCount);
        System.out.println("#even: " + evenCount);
    }

    private static int countOdds(int[] values)
    {
        int oddCount = 0;
        for (int i = 0; i < values.length; i++)
        {
            if (values[i] % 2 != 0)
            {
                oddCount++;
            }
        }
        return oddCount;
    }
}
