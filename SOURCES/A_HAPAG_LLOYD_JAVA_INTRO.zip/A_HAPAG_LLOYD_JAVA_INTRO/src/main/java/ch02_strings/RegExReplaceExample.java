package ch02_strings;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class RegExReplaceExample
{
    public static void main(String[] args)
    {
        String str = "value  with spaces";
        String regex = "\\s+";
        String replacement = "-***-";
    
        String no_spaces = str.replaceAll(regex, replacement);
        System.out.println(no_spaces);
          
        String no_spaces2 = "value   with  spaces".replaceAll("\\s", "-***-");
        System.out.println(no_spaces2);
                
        String no_words = "value with spaces".replaceAll("\\w+", "-/-");
        System.out.println(no_words);
        
        String no_digits = "123 LOS".replaceAll("\\d+", "");
        System.out.println(no_digits);

        System.out.println("\\w+: " +  "ABC_abc_123".matches("\\w+"));
        
        // "Dreh mal am Herd."
        // => Space und . durch ""
        String plainText = "Dreh mal,,, am Herd!!.".replaceAll("[\\s\\.,!]", "");
        System.out.println(plainText);        
    }
}
