package ch02_strings;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class ToTitleCaseExample
{
    public static void main(String[] args)
    {
        System.out.println(toTitleCase("dies ist ein test"));
    }

    static String toTitleCase(String input)
    {
        char[] inputChars = input.toCharArray();
        boolean capitalizeNextChar = true;
        for (int i = 0; i < inputChars.length; i++)
        {
            char currentChar = inputChars[i];
            if (capitalizeNextChar)
            {
                inputChars[i] = Character.toUpperCase(currentChar);
                capitalizeNextChar = false;
            }
            if (Character.isWhitespace(currentChar) || currentChar == '-')
            {
                capitalizeNextChar = true;
            }
        }
        return new String(inputChars);
    }
}
