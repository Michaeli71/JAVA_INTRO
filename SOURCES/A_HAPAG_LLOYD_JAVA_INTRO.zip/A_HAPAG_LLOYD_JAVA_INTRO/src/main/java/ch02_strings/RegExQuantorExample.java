package ch02_strings;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class RegExQuantorExample
{
    public static void main(String[] args)
    {     
        String regex = "[ab]+"; 
        
        System.out.println("a".matches(regex));
        System.out.println("b".matches(regex));
        System.out.println("ab".matches(regex));
        System.out.println("ba".matches(regex));
        System.out.println("abba".matches(regex));
        System.out.println("bababaab".matches(regex));
        
        
        String regex2 = "a[abc]*"; 
        
        System.out.println("a".matches(regex2));
        System.out.println("ac".matches(regex2));
        System.out.println("ab".matches(regex2));
        System.out.println("aba".matches(regex2));
        System.out.println("abba".matches(regex2));
        System.out.println("abababaab".matches(regex2));
    }
}
