package ch02_strings;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class StringBuilderExample
{
    public static void main(String args[])
    {
        String s = "";
        s += "I have ";
        s += 50;
        s += " cats.";
        System.out.println(s);

        StringBuilder sb = new StringBuilder();
        sb.append("I have ");
        sb.append(50);
        sb.append(" cats.");
        System.out.println(sb);
    }
}