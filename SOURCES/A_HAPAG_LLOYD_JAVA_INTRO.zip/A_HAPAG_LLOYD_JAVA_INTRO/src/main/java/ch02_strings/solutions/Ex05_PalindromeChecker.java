package ch02_strings.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex05_PalindromeChecker
{
    public static void main(String[] args)
    {
        // "OTTO", "ANNA",
        // KÜR ---------------------
        // "Dreh mal am Herd"
        System.out.println(isPalindrome("OTTO"));
        System.out.println(isPalindrome("OTATO"));
        System.out.println(isPalindrome("OTATOA"));  

        System.out.println(isPalindromeRec("OTTO"));
        System.out.println(isPalindromeRec("OTATO"));
        System.out.println(isPalindromeRec("OTATOA"));  
        
        // Wenn Baustein vorhanden, etwaa Aufgabe 4
        isPalindromeWithHelper("OTTO");
        isPalindromeWithHelper("OTATO");
        isPalindromeWithHelper("OTATOA");  
    }

    private static boolean isPalindrome(String input)
    {
        int left = 0;
        int right = input.length() - 1;
        
        while (left < right)
        {
            if (input.charAt(left) == input.charAt(right))
            {
                left++;
                right--;
            }
            else
                return false;
        }
        
        return true;
    }
    
    // nicht-optimale rekursive Lösung, morgen Verbesserung
    private static boolean isPalindromeRec(String input)
    {
        if (input.length() <= 1)
            return true;
        
        int left = 0;
        int right = input.length() - 1;
        
        if (input.charAt(left) == input.charAt(right))
        {
            String remaining = input.substring(left + 1, right);
            return isPalindromeRec(remaining);
        }
        
        return false;
    }
    
    
    
    // ------------------------------------------------------------
    
    private static void isPalindromeWithHelper(String input)
    {
        String reversed = Ex04_ReverseString.reverseString(input);
        
        boolean isPalindrome = input.equals(reversed);
        System.out.println("isPalindrome: " + isPalindrome);
    }

    private static void isPalindromeWithHelper2(String input)
    {
        // später in den Folien StringBuilder
        String reversed = new StringBuilder(input).reverse().toString();
        
        boolean isPalindrome = input.equals(reversed);
        System.out.println("isPalindrome: " + isPalindrome);
    }
}
