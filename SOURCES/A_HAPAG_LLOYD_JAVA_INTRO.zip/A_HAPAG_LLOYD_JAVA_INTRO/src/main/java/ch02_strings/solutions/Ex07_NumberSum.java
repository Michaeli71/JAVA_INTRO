package ch02_strings.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex07_NumberSum
{
    public static void main(String[] args)
    {        
        String input = "a1bb2ccc3";
                        //"a7b5c2d4ef12stop";
     
        int sum = 0;
        for (int i = 0; i < input.length(); i++)
        {
            char val = input.charAt(i);
            if (Character.isDigit(val))
            {
                sum += Integer.valueOf("" + val);
            }
        }
        
        System.out.println("sum of digits: " + sum);
    }
}
