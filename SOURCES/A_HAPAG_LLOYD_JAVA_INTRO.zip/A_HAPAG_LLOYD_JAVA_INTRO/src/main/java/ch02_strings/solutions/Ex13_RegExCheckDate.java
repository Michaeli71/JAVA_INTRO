package ch02_strings.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex13_RegExCheckDate
{
    public static void main(String[] args)
    {
        String regex = "\\d{1,2}\\. [a-zA-Z]+ \\d{2,4}"; 
        
        System.out.println("7. Februar 1971".matches(regex));
        System.out.println("23. November 2020".matches(regex));
        System.out.println("14. Sept 21".matches(regex));
        // System.out.println("25. März 75".matches(regex));
    }
}
