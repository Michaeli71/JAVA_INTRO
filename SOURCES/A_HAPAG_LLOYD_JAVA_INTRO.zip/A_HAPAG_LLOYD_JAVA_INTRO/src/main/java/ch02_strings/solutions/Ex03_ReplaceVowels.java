package ch02_strings.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex03_ReplaceVowels
{
    public static void main(String[] args)
    {
        System.out.println(removeVowels("Dies ist ein Test. äüö!"));
        System.out.println(replaceVowels("Dies ist ein Test. äüö!", "_"));
        System.out.println(replaceVowels("Dies ist ein Test. äüö!", "$$$"));
    }
    
    private static String removeVowels(String input)
    {        
        String result = "";
        for (int i = 0; i < input.length(); i++)
        {
            char currentChar = input.charAt(i);
            if (!isVowel(currentChar))
            {
                result += "" + currentChar;
            }
        }
        return result;
    }

    private static String replaceVowels(String input, String replacement)
    {        
        String result = "";
        for (int i = 0; i < input.length(); i++)
        {
            char currentChar = input.charAt(i);
            if (isVowel(currentChar))
            {
                result += replacement;
            }
            else
            {
                result += "" + currentChar;
            }
        }
        return result;
    }

    static boolean isVowel(char currentChar)
    {
        return "AEIOUÄÖÜaeiouäöü".contains("" + currentChar);
    }
}
