package ch02_strings.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex04_ReverseString
{
    public static void main(String[] args)
    {
        System.out.println(reverseString("A"));
        System.out.println(reverseString("ABCD"));
        System.out.println(reverseString("ABCDEFGHI"));
        System.out.println(reverseString("was it a car or a cat i saw"));
    }
    
    static String reverseString(String input)
    {
        // rekursiver Abbruch
        if (input.length() <= 1)
            return input;
    
        String firstChar = input.substring(0, 1); // "" + input.charAt(0);
        String remaining = input.substring(1);
    
        // rekursiver Abstieg
        return reverseString(remaining) + firstChar;
    }
}
