package ch02_strings.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex14_RegExInputChecker
{
    public static void main(String[] args)
    {
        String regex = "[a-z =(]+\\d*[a-z);]+";

        System.out.println("abc123xyz".matches(regex));
        System.out.println("def myfunc(value)".matches(regex));
        System.out.println("var g = 123;".matches(regex));                
    }
}
