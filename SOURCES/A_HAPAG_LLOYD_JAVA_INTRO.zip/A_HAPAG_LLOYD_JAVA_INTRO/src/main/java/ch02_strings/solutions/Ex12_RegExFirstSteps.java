package ch02_strings.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex12_RegExFirstSteps
{
    public static void main(String[] args)
    {
        String regex = "[a-zA-Z0-9]+"; 
                    
        System.out.println("ABCDef1234".matches(regex));
        System.out.println("xy!".matches(regex));
        
        String regex2 = "\\w+!*"; 
        
        System.out.println("ABCDef1234".matches(regex2));
        System.out.println("xy!!!!".matches(regex2));
    }
}
