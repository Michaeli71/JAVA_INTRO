package ch02_strings;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class RegExRangeExample
{
    public static void main(String[] args)
    {
        String str = "X";
        String regex = "[A-Z]"; 
        // Test auf Großbuchstabe (ASCII)
        boolean matches = str.matches(regex);
        System.out.println(matches);
        
        boolean matches2 = "x".matches("[A-Zxyz]");
        System.out.println(matches2);
        
        // Alternative: pre-compiled pattern
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        matches = matcher.matches();
        System.out.println(matches);
    }
}
