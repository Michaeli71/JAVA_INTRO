package ch08_10_date_ex_file;

import java.util.List;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class MultipleExceptions
{
    public static void main(String[] args)
    {
        var names = List.of("Tim", "Tom", "Mike");
        for (int i = 0; i < 5; i++)
        {
            try
            {
                int value = Integer.valueOf(names.get(i));
            }
            catch (NumberFormatException | ArithmeticException ex)
            {
                System.out.println("can't parse to integer");
            }
            catch (ArrayIndexOutOfBoundsException aioobe)
            {
                System.out.println("wrong index");
            }
        }
    }
}
