package ch08_10_date_ex_file;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.stream.Stream;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class DirectoryTreeWithPath
{
    public static void main(String[] args) throws IOException
    {
        Path currentDir = Path.of("."); // current directory

        printDirectory(currentDir, 0);
    }

    static void printDirectory(Path currentDir, int level) throws IOException
    {
        try (Stream<Path> dirContent = Files.list(currentDir))
        {        
            for (Path path : dirContent.toList())
            {
                System.out.print("    ".repeat(level));
                System.out.println(path.getFileName());
                if (Files.isDirectory(path))
                {
                    printDirectory(path, level + 1);
                }
            }
        }
    }
}