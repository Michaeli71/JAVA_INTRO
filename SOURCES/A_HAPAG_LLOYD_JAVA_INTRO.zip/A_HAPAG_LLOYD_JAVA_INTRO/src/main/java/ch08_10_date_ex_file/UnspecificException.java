package ch08_10_date_ex_file;

import java.util.List;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class UnspecificException
{
    public static void main(String[] args)
    {
        List<String> names = List.of("Tim", "Tom", "Mike");
        try
        {
            System.out.println("INVALID INDEX: " + names.get(42));
        }
        catch (Exception ex)
        {
            System.out.println(("an unspecified error occurred. seams to be wrong index"));
        }
    }
}
