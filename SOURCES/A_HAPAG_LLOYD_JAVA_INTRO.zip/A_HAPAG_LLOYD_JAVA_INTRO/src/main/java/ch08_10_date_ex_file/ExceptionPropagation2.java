package ch08_10_date_ex_file;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class ExceptionPropagation2
{
    static class OwnCheckException extends Exception
    {
    }

    public static void main(String[] args) throws OwnCheckException
    {
        func1();
    }

    static void func1() throws OwnCheckException
    {
        func2();
    }

    static void func2() throws OwnCheckException
    {
        throw new OwnCheckException();
    }
}