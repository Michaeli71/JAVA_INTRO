package ch08_10_date_ex_file;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Stream;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class ListDirectory
{
    public static void main(String[] args) throws IOException
    {
        var dirContent = listDirectory(Path.of("."));
        
        for (var path : dirContent)
        {
            if (Files.isDirectory(path))
            {
                System.out.println(path + " is a directory");
            }
            if (Files.isRegularFile(path))
            {
                System.out.println(path + " is a file");
            }
        }
    }

    static List<Path> listDirectory(Path dir) throws IOException
    {
        try (Stream<Path> content = Files.list(dir))
        {
            return content.toList();
        }
    }
}
