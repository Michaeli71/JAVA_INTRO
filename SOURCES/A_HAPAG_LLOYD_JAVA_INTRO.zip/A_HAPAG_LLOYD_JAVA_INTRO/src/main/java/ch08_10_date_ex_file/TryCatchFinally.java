package ch08_10_date_ex_file;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class TryCatchFinally
{
    public static void main(String[] args)
    {
        String[] names = { "Tim", "Tom", "Mike" };
        try
        {
            System.out.println("INVALID INDEX: " + names[42]);
        }
        catch (ArrayIndexOutOfBoundsException aioobe)
        {
            System.out.println("wrong index");
        }
        finally
        {
            System.out.println("ALWAYS EXECUTED");
        }
    }

    void ensureValueInRange(int value, int lowerBound, int upperBound)
    {
        if (value < lowerBound || value > upperBound)
            throw new IllegalArgumentException("out of bounds");
    }
}
