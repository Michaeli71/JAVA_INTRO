package ch08_10_date_ex_file;

import java.time.LocalDate;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class LocalDateExample
{
    public static void main(String[] args)
    {
        final LocalDate now = LocalDate.now();
        System.out.println("Today: " + now);
        System.out.println("DayOfWeek: " + now.getDayOfWeek());
        System.out.println("DayOfMonth: " + now.getDayOfMonth());
        System.out.println("DayOfYear: " + now.getDayOfYear());
        System.out.println("Month: " + now.getMonth());
        System.out.println("Length Of Month: " + now.lengthOfMonth());
        System.out.println("Days in Month: " + now.getMonth().length(now.isLeapYear()));
        System.out.println("Length Of Year: " + now.lengthOfYear());
        System.out.println("Year: " + now.getYear());
    }
}