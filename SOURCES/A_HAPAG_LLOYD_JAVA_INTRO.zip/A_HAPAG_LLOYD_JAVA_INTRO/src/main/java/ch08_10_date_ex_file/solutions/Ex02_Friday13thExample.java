package ch08_10_date_ex_file.solutions;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex02_Friday13thExample
{
    private Ex02_Friday13thExample()
    {
    }

    public static void main(String[] args)
    {
        System.out.println(allFriday13th(LocalDate.of(2013, 1, 1), LocalDate.of(2016, 1, 1)));        
    }
    
    static List<LocalDate> allFriday13th(final LocalDate start, final LocalDate end)
    {
        final Predicate<LocalDate> isFriday = day -> day.getDayOfWeek() ==
                        DayOfWeek.FRIDAY;
        final Predicate<LocalDate> is13th = day -> day.getDayOfMonth() == 13;

        final List<LocalDate> allFriday13th = start.datesUntil(end)
                        .filter(isFriday)
                        .filter(is13th)
                        .collect(Collectors.toList());
        return allFriday13th;
    }
}
