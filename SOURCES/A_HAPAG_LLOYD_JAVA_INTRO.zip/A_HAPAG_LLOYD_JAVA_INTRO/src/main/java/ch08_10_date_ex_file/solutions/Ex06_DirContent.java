package ch08_10_date_ex_file.solutions;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Stream;


/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex06_DirContent
{
    public static void main(String[] args) throws IOException
    {
        Path dir = Path.of(".");
        try (Stream<Path> dirContent = Files.list(dir))
        {
            List<Path> dirContentAsList = dirContent.toList();
            for (Path current : dirContentAsList)
            {
                long size = Files.size(current);
                boolean isDir = Files.isDirectory(current);
                String pureName = current.getFileName().toString();
                String dirMarker = isDir ? " [DIR]" : "";
                String sizeInfoMarker = isDir ? " -/-" : " " + size;
                System.out.println(pureName + sizeInfoMarker + dirMarker);
            }
        }
    }
}
