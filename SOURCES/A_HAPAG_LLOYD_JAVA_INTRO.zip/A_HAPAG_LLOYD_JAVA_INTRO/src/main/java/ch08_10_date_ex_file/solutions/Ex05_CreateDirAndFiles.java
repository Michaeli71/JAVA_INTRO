package ch08_10_date_ex_file.solutions;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex05_CreateDirAndFiles 
{
	public static void main(String[] args) throws IOException 
	{
	    Files.createDirectory(Path.of("new_and_empty"));
	    Files.createDirectory(Path.of("another-dir"));
	    Files.createDirectory(Path.of("files-examples-dir"));
		
	    var newCsvFile = Files.createFile(Path.of("files-examples-dir/example-data.csv"));
	    var newTxtFile = Files.createFile(Path.of("files-examples-dir/example-file.txt"));
	}
}
