package ch08_10_date_ex_file.solutions;

import java.time.LocalDate;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex01_Weekdays
{
    public static void main(String[] args)
    {
        var christmasEve = LocalDate.of(2019, 12, 24);
        var jan31_2020 = LocalDate.of(2020, 1, 31);

        System.out.println(christmasEve.getDayOfWeek());
        System.out.println(jan31_2020.getDayOfWeek());
    }
}
