package ch08_10_date_ex_file.solutions;

import java.time.Year;
import java.util.stream.IntStream;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex03_LeapYear
{
    private Ex03_LeapYear()
    {
    }

    public static void main(String[] args)
    {
        System.out.println(countLeapYears(Year.of(2010), Year.of(2019)));
        System.out.println(countLeapYears(Year.of(2000), Year.of(2019)));
    }

    static long countLeapYears(Year start, Year end)
    {
        return IntStream.range(start.getValue(), end.getValue()).
                        filter(Year::isLeap).
                        count();
    }

    static boolean isLeap(final int year)
    {
        final boolean everyFourthYear = year % 4 == 0;
        final boolean isSecular = year % 100 == 0;
        final boolean isSecularSpecial = year % 400 == 0;

        return everyFourthYear && (!isSecular || isSecularSpecial);
    }
}
