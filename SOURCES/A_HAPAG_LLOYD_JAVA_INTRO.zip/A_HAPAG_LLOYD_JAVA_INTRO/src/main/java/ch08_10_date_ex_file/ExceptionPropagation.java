package ch08_10_date_ex_file;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class ExceptionPropagation
{
    public static void main(String[] args)
    {
        func1();
    }
    
    static void func1()
    {
        func2();
    }
    
    static void func2()
    {
        throw new IllegalStateException("propagate me");
    }
}