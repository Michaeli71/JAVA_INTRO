package ch01_quickstart.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex10_Fibonacci
{
    public static void main(String[] args)
    {
        System.out.println(fibRec(5));
        System.out.println(fibRec(8));
        
        System.out.println(fibRec(35));
        System.out.println(fibRec(42));
        System.out.println(fibRec(47));
        
        // Abhilfe: MEMOIZATION => "Java Challenge"
    }

    private static long fibRec(int n)
    {
        // BONUS: Parameterprüfung
        if (n <= 0)
            throw new IllegalArgumentException("n must be >= 1");
        
        // rekursive Abbruch
        if (n == 1 || n == 2)
            return 1;
        
        return fibRec(n-1) + fibRec(n-2);
    }
}
