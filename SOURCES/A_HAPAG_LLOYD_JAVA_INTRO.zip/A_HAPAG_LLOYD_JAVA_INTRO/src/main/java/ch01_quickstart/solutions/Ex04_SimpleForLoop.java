package ch01_quickstart.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex04_SimpleForLoop
{
    public static void main(String[] args)
    {
        for (int i = 0; i < 10; i++)
        {
            System.out.println("Michael: " + i);
        }
        
        for (int i = 0; i < 20; i += 2)
        {
            System.out.println("Peter: " + i);
        }
    }
}
