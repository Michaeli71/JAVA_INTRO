package ch01_quickstart.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex06_ProperDivisors
{
    public static void main(String[] args)
    {
        int value = 12;
        
        for (int i = 1; i <= value / 2; i++)
        {
            if (value % i == 0)
            {
                System.out.println(i);
            }
        }
        
        findProperDivisor(20);
        findProperDivisor(123);
        findProperDivisor(7);
        findProperDivisor(7271);
    }

    private static void findProperDivisor(int value)
    {
        for (int i = 1; i <= value / 2; i++)
        {
            if (value % i == 0)
            {
                System.out.println(i);
            }
        }
    }
}
