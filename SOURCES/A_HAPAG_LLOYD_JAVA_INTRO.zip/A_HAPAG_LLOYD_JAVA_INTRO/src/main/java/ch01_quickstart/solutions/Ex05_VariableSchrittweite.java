package ch01_quickstart.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex05_VariableSchrittweite
{
    public static void main(String[] args)
    {
        int value = 0;
        int step = 1;
        
        while (value < 70)
        {
            System.out.println("Wert: " + value + " / Schrittweite: " + step);
            value += step;
            step += 2;
        }       
    }
}
