package ch01_quickstart.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex07_NestedLoops
{
    public static void main(String[] args)
    {       
        printNumberTriangle(4);
        printNumberTriangleCont(4);
    }

    private static void printNumberTriangle(int num)
    {
        for (int y = 1; y <= num; y++)
        {
            for (int x = 1; x <= y; x++)
                System.out.print(x);
            
            System.out.println();
        }
    }
    
    private static void printNumberTriangleCont(int num)
    {
        int value = 1;
        for (int y = 1; y <= num; y++)
        {
            for (int x = 1; x <= y; x++)
            {
                System.out.print(value + " ");
                value++;
            }
            System.out.println();
        }
    }
}
