package ch01_quickstart;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class RecursionNestingOfInvocations
{
    public static void main(String args[])
    {
        recursiveCalls(0);
    }

    public static void recursiveCalls(int value)
    {
        System.out.println("BEFORE " + value);
        value++;
        if (value < 5)
        {
            // rekursiver Abstieg
            recursiveCalls(value); 
        }
        System.out.println("AFTER " + value);
    }
}
