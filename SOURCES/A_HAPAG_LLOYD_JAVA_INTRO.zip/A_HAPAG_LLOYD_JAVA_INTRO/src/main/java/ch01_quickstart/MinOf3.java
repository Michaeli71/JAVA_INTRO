package ch01_quickstart;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class MinOf3
{
    public static void main(String[] args)
    {
        System.out.println(min_of_3(4, 2, 1));
    }

    static int min_of_3(int x, int y, int z)
    {
        if (x < y)
        {
            if (x < z)
            {
                return x;
            }
            else
            {
                return z;
            }
        }
        else if (y < z)
        {
            return y;
        }
        else
            return z;
    }
}