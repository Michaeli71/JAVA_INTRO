package ch01_quickstart;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class ConstantsExample
{
    public static void main(String[] args)
    {
        final int age = 40;
        // The final local variable age cannot be assigned. It must be blank and not using a compound assignment
        //age = 50;
    }
}
