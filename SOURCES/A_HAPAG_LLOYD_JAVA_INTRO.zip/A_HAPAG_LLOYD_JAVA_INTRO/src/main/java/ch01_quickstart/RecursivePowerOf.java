package ch01_quickstart;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
// x hoch y
public class RecursivePowerOf
{
    public static void main(String[] args)
    {
        System.out.println(powerOf(2, 0));
        System.out.println(powerOf(2, 4));
        System.out.println(powerOf(2, 8));

        System.out.println(powerOf(4, 2));
    }

    static int powerOf(int x, int y)
    {
        if (y == 0)
            return 1;

        return x * powerOf(x, y - 1);
    }
}
