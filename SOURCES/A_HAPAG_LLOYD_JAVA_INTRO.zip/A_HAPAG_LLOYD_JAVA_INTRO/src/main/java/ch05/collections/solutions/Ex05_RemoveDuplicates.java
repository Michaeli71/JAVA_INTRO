package ch05.collections.solutions;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex05_RemoveDuplicates
{
    private Ex05_RemoveDuplicates()
    {
    }

    static <T> List<T> removeDuplicates(final List<T> inputs)
    {
        final List<T> result = new ArrayList<>();
        final Set<T> alreadySeen = new HashSet<>();

        final Iterator<T> it = inputs.iterator();
        while (it.hasNext())
        {
            final T elem = it.next();

            // Prüfe auf Duplikat
            if (!alreadySeen.contains(elem))
            {            
                alreadySeen.add(elem);
                result.add(elem);
            }
        }

        return result;
    }
    
    static <T> List<T> removeDuplicatesWithItertorRemove(final List<T> inputs)
    {
        final List<T> result = new ArrayList<>(inputs);
        final Set<T> numbers = new HashSet<>();

        final Iterator<T> it = result.iterator();
        while (it.hasNext())
        {
            final T elem = it.next();

            // Prüfe auf Duplikat
            if (numbers.contains(elem))
                it.remove();
            else
                numbers.add(elem);
        }

        return result;
    }

    // Ergänzendes Wissen:
    
    static <T> List<T> removeDuplicatesV2(final List<T> inputs)
    {
        return new ArrayList<>(new LinkedHashSet<>(inputs));
    }

    static <T> List<T> removeDuplicatesV3(final List<T> inputs)
    {
        return inputs.stream().distinct().collect(Collectors.toList());
    }

    public static void main(String[] args)
    {
        System.out.println(removeDuplicates(List.of(1, 1, 2, 3, 2, 2, 4, 1, 4, 2, 3)));
        System.out.println(removeDuplicates(List.of(7, 5, 7, 3, 1)));
        System.out.println(removeDuplicates(List.of(1, 1, 1, 1)));
    }
}
