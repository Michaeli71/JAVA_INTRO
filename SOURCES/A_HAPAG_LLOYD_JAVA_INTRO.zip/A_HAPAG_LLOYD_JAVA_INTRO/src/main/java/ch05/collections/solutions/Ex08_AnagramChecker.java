package ch05.collections.solutions;

import java.util.Map;
import java.util.TreeMap;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex08_AnagramChecker
{
    private Ex08_AnagramChecker()
    {
    }

    public static boolean isAnagram(final String str1, final String str2)
    {
        final Map<Character, Integer> charCounts1 = calcCharFrequencies(str1);
        final Map<Character, Integer> charCounts2 = calcCharFrequencies(str2);

        return charCounts1.equals(charCounts2);
    }

    private static Map<Character, Integer> calcCharFrequencies(final String input)
    {
        final Map<Character, Integer> charCounts = new TreeMap<>();

        for (char currentChar : input.toUpperCase().toCharArray())
        {
            // Elegantere Version später bei Lambdas
            if (charCounts.containsKey(currentChar))
                charCounts.put(currentChar, charCounts.get(currentChar) + 1);
            else 
                charCounts.put(currentChar, 0);
        }
        return charCounts;
    }
    
    public static void main(String[] args)
    {
       System.out.println(isAnagram("AMPEL", "LAMPE"));
       System.out.println(isAnagram("AMPEL", "PALME")); 
       System.out.println(isAnagram("AMPEL", "AMEISE")); 
    }
}
