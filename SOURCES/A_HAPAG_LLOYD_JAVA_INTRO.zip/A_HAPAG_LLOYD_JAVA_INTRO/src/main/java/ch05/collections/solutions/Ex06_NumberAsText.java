package ch05.collections.solutions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex06_NumberAsText
{
    private Ex06_NumberAsText()
    {
    }

    static Map<Integer, String> valueToTextMap = Map.of(0, "ZERO",
                                                        1, "ONE", 2, "TWO", 3, "THREE", 4, "FOUR", 5, "FIVE",
                                                        6, "SIX", 7, "SEVEN", 8, "EIGHT", 9, "NINE");


    static String digitAsText(int n)
    {
        int reminder = n % 10;

        return valueToTextMap.getOrDefault(reminder, "-?-");
    }

    static String digitAsText(String strDigit)
    {        
        int reminder = Integer.valueOf(strDigit) % 10;

        return digitAsText(reminder);
    }
    
    static String numberAsText(final int n)
    {
        String value = "";
        
        int remainingValue = n;
        while (remainingValue > 0)
        {
            var reminder = remainingValue % 10;
            var reminderAsText = digitAsText(reminder);
            
            
            value = reminderAsText + " " + value;

            remainingValue /= 10;
        }

        return value.trim();
    }
    
    static String numberAsTextTogether(final int n)
    {
        List<String> numbers = new ArrayList<>();

        int remainingValue = n;
        while (remainingValue > 0)
        {
            var reminder = remainingValue % 10;
            var reminderAsText = digitAsText(reminder);
            
            numbers.add(0, reminderAsText);

            remainingValue /= 10;
        }
        
        return numbers.toString();
    }
    
    static String numberAsTextTogetherV2(final int n)
    {
        List<String> numbers = new ArrayList<>();

        int remainingValue = n;
        while (remainingValue > 0)
        {
            var reminder = remainingValue % 10;
            var reminderAsText = digitAsText(reminder);
            
            numbers.add(reminderAsText);

            remainingValue /= 10;
        }
        
        Collections.reverse(numbers);
        return numbers.toString();
    }
    
    static String numberAsTextV2(final int n)
    {
        String strN = "" + n;

        String result = "";
        for (char ch : strN.toCharArray())
        {
            result += digitAsText("" + ch) + " ";
        }

        return result.trim();
    }
    
    static String numberAsTextV3(final int n)
    {
        String strN = "" + n;

        String result = "";
        for (int i = 0; i < strN.length(); i++)
        {
            String strDigut = strN.substring(i, i + 1);
            result += digitAsText(strDigut) + " ";
        }

        return result.trim();
    }
    
    public static void main(String[] args)
    {
        System.out.println(numberAsText(7271));
        System.out.println(numberAsTextV2(7271));
        System.out.println(numberAsTextV3(7271));
        
        System.out.println(numberAsTextTogether(7271));
        System.out.println(numberAsTextTogetherV2(7271));
    }
    
}
