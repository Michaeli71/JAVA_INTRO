package ch05.collections.solutions;

import java.util.Map;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex06_NumberAsText
{
    private Ex06_NumberAsText()
    {
    }

    static Map<Integer, String> valueToTextMap = Map.of(0, "ZERO",
                                                        1, "ONE", 2, "TWO", 3, "THREE", 4, "FOUR", 5, "FIVE",
                                                        6, "SIX", 7, "SEVEN", 8, "EIGHT", 9, "NINE");


    static String digitAsText(int n)
    {
        int reminder = n % 10;

        return valueToTextMap.getOrDefault(reminder, "-?-");
    }

    static String digitAsText(String ch)
    {        
        int reminder = Integer.valueOf(ch) % 10;

        return valueToTextMap.getOrDefault(reminder, "-?-");
    }
    
    static String numberAsText(final int n)
    {
        String value = "";
        int remainingValue = n;
        while (remainingValue > 0)
        {
            var reminder = remainingValue % 10;
            var reminderAsText = digitAsText(reminder);
            value = reminderAsText + " " + value;

            remainingValue /= 10;
        }

        return value.trim();
    }
    
    static String numberAsTextV2(final int n)
    {
        String strN = "" + n;

        String result = "";
        for (char ch : strN.toCharArray())
        {
            result += digitAsText("" + ch) + " ";
        }

        return result.trim();
    }
    
    public static void main(String[] args)
    {
        System.out.println(numberAsText(7271));
        System.out.println(numberAsTextV2(7271));
    }
    
}
