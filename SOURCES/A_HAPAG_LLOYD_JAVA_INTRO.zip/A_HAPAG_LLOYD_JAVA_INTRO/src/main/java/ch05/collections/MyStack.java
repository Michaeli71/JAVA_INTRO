package ch05.collections;

import java.util.ArrayList;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class MyStack<E> implements IStack<E>
{
    private final ArrayList<E> values = new ArrayList<>();

    @Override
    public void push(final E elem)
    {
        values.add(elem);
    }

    @Override
    public E pop()
    {
        return values.remove(values.size() - 1);
    }

    @Override
    public E peek()
    {
        return values.get(values.size() - 1);
    }

    @Override
    public boolean isEmpty()
    {
        return values.isEmpty();
    }

    public static void main(String[] args)
    {
        IStack<String> stack = new MyStack<>();
        stack.push("first");
        stack.push("second");

        System.out.println("PEEK: " + stack.peek());
        System.out.println("POP: " + stack.pop());
        System.out.println("POP: " + stack.pop());
        System.out.println("ISEMPTY: " + stack.isEmpty());
        System.out.println("POP: " + stack.pop());
    }
}