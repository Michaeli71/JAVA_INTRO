package ch05.collections;

import java.util.LinkedList;
import java.util.List;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class OwnQueueExample
{
    private OwnQueueExample()
    {
    }

    
    static class MyQueue<E>
    {
        private final List<E> values = new LinkedList<>();
    
        public void enqueue(final E elem)
        {
            values.add(elem);
        }
    
        public E dequeue()
        {
            return values.remove(0);
        }
    
        public E peek()
        {
            return values.get(0);
        }
    
        public boolean isEmpty()
        {
            return values.isEmpty();
        }
    }
    
    public static void main(final String[] args)
    {
        final MyQueue<String> waitingPersons = new MyQueue<>();
    
        waitingPersons.enqueue("Marcello");
        waitingPersons.enqueue("Michael");
        waitingPersons.enqueue("Karthi");
    
        while (!waitingPersons.isEmpty())
        {
            if (waitingPersons.peek().equals("Michael"))
            {
                // Am Ende "neu anstellen" und verarbeiten
                waitingPersons.enqueue("Michael again");
                waitingPersons.enqueue("Last Man");
            }
            final String nextPerson = waitingPersons.dequeue();
            System.out.println("Processing " + nextPerson);
        }
    }
}
