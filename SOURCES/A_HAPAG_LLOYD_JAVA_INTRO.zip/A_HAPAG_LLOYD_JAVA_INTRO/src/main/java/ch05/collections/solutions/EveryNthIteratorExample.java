package ch05.collections.solutions;

import java.util.Iterator;
import java.util.List;

/*
 * Implementieren Sie einen Iterator namens EveryNth, der jedes n-te Element durchläuft. 
 * Also für die Eingabe [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12] beispielsweise folgende Werte ausgibt:
•   Mit Schrittweite 3:     1, 4, 7 ,10 
•   Mit Schrittweite 5:     1, 6, 11
 */
public class EveryNthIteratorExample
{
    public static void main(String[] args)
    {
        var values = List.of(-2, -4, -8, -47, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12);        
        Iterator<Integer> itEvery3rd = new EveryNthIterator<>(values, 3, 4);
        
        var textValues = List.of("UNSINN", "BLA", "FASEL", "DATA1", "DATA2", "DATA3", "DATA4", "DATA5");
        Iterator<String> itEvery2nd = new EveryNthIterator<>(textValues, 2, 3);
        
        // loop through data
        printOutData(itEvery3rd);        
        printOutData(itEvery2nd);
    }

    // spezielle generische Syntax
    private static <E> void printOutData(Iterator<E> it)
    {
        while (it.hasNext())
        {
            E value = it.next();
            System.out.println(value);
        }
    }
}
