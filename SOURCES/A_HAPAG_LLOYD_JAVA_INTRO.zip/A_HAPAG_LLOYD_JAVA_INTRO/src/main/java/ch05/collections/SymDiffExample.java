package ch05.collections;

import java.util.HashSet;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class SymDiffExample
{
    HashSet<Integer> symDiff(HashSet<Integer> values1, HashSet<Integer> values2)
    {
        // Differenzmengen bilden
        HashSet<Integer> diff1_2 = new HashSet<>(values1);
        diff1_2.removeAll(values2);
        HashSet<Integer> diff2_1 = new HashSet<>(values2);
        diff2_1.removeAll(values1);

        // Vereinigung bilden
        HashSet<Integer> result = new HashSet<>();
        result.addAll(diff1_2);
        result.addAll(diff2_1);
        return result;
    }
    
    HashSet<Integer> symDiff_clearer(HashSet<Integer> values1, HashSet<Integer> values2)
    {
        // Schnittmenge bilden
        HashSet<Integer> intersection = new HashSet<>(values1); 
        intersection.retainAll(values2);
        
        // Vereinigung bilden und Schnittmenge abziehen
        HashSet<Integer> result = new HashSet<>();
        result.addAll(values1);
        result.addAll(values2);
        result.removeAll(intersection);
        return result;
    }
}
