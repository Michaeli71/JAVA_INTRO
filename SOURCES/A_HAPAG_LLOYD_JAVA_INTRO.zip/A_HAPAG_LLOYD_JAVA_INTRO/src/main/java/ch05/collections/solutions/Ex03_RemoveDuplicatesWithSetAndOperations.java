package ch05.collections.solutions;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex03_RemoveDuplicatesWithSetAndOperations
{
    public static void main(String[] args)
    {
        List<String> cities = List.of("Kiel", "Hamburg", "Zürich", "Bremen",
                                      "Hamburg", "Zürich", "Kiel", "Bremen");
        
        System.out.println(new HashSet<>(cities));
        
        // Set Operations
        var fibNumbers = new HashSet<>(Set.of(1, 2, 3, 5, 8, 13, 21));
        var naturalNumbers = new HashSet<>(Set.of(1, 2, 3, 4, 5, 6, 7));

        var intersection = new HashSet<>(fibNumbers);
        intersection.retainAll(naturalNumbers);
        System.out.println("Intersection Fib \u2229 \u2115: " + intersection);
        
        var fib_minus_N = new HashSet<>(fibNumbers);
        fib_minus_N.removeAll(naturalNumbers);        
        System.out.println("Fib - \u2115: " + fib_minus_N);

        var N_minus_fib = new HashSet<>(naturalNumbers);
        N_minus_fib.removeAll(fibNumbers);
        System.out.println("\u2115 - Fib: " + N_minus_fib);
        
        System.out.println("Symm. Diff: " + symDiff(fibNumbers, naturalNumbers));
        
        
        System.out.println("Symm. Diff: " + symDiff(Set.of("A", "B", "C", "D", "E", "F"), 
                                                    Set.of("D", "E", "F", "G", "H", "I")));
    }
    
    static <T> Set<T> symDiff(Set<T> values1, Set<T> values2)
    {
        // Schnittmenge bilden
        Set<T> intersection = new HashSet<>(values1); 
        intersection.retainAll(values2);
        
        // Vereinigung bilden und Schnittmenge abziehen
        Set<T> result = new TreeSet<>();
        result.addAll(values1);
        result.addAll(values2);
        result.removeAll(intersection);
        return result;
    }
}
