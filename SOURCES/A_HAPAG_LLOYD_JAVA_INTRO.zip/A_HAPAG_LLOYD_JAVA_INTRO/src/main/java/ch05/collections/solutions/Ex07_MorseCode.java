package ch05.collections.solutions;

import java.util.Map;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex07_MorseCode
{
    private Ex07_MorseCode()
    {
    }

    static String toMorseCode(final String input)
    {
        String convertedMsg = "";

        for (int i = 0; i < input.length(); i++)
        {
            var currentChar = input.charAt(i);
            var convertedLetter = convertToMorseCode(currentChar);

            convertedMsg += convertedLetter;
            convertedMsg += "   ";
        }

        return convertedMsg.toString().trim();
    }

    private static String convertToMorseCode(final char currentChar)
    {
        Map<Character, String> morseCodeMapping = Map.of('E', ".", 'O', "- - -", 
                                                         'S', ". . .", 'T', "-", 'W', ". - -");

        return morseCodeMapping.getOrDefault(currentChar, "?");
    }
    
    public static void main(String[] args)
    {
        System.out.println(toMorseCode("OST"));
        System.out.println(toMorseCode("WEST"));
        System.out.println(toMorseCode("TWEET"));
    }
}
