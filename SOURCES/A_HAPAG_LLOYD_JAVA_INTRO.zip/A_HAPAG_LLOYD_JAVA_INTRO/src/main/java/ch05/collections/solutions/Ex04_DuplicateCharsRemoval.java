package ch05.collections.solutions;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex04_DuplicateCharsRemoval
{
    private Ex04_DuplicateCharsRemoval()
    {
    }

    static String removeDuplicates(final String input)
    {
        var result = "";
        final Set<Character> alreadySeen = new HashSet<>();

        for (int i = 0; i < input.length(); i++)
        {
            final char currentChar = input.charAt(i);
            if (!alreadySeen.contains(currentChar))
            {
                alreadySeen.add(currentChar);

                result += currentChar;
            }
        }

        return result;
    }

    // Ergänzendes Wissen
    
    static String removeDuplicatesImproved(final String input)
    {
        final IntStream chars = input.chars();
        return chars.distinct().mapToObj(i -> (char) i + "").collect(Collectors.joining());
    }
    
    public static void main(String[] args)
    {
        System.out.println(removeDuplicates("bananas"));
        System.out.println(removeDuplicates("lalalamama"));
        System.out.println(removeDuplicates("MICHAEL"));
    }    
}
