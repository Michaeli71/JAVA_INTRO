package ch05.collections;

import java.util.Iterator;

public class ArrayIteratorAdapter<T> implements Iterator<T>
{
    int       currentPosition;

    final T[] adaptee;

    public ArrayIteratorAdapter(final T[] adaptee)
    {
        this.adaptee = adaptee;
        this.currentPosition = 0;
    }

    @Override
    public boolean hasNext()
    {
        return currentPosition < adaptee.length;
    }

    @Override
    public T next()
    {
        final T next = adaptee[currentPosition];
        currentPosition++;
        return next;
    }
    
    
    public static void main(String[] args)
    {
        String[] names = { "Tim", "Tom", "Jerry", "James", "Julius" };
        
        Iterator<String> it = new ArrayIteratorAdapter<>(names);
        while (it.hasNext())
            System.out.println(it.next());
    }
}
