package ch05.collections.solutions;

import java.util.ArrayList;
import java.util.List;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex01_TennisClubMembers
{
    public static void main(String[] args)
    {
        List<String> mitgliederListe = new ArrayList<>();

        mitgliederListe.addAll(List.of("Michael", "Tim", "Werner"));

        System.out.println("Jana? " + mitgliederListe.contains("Jana"));

        mitgliederListe.add("Andreas");
        mitgliederListe.addAll(List.of("Lili", "Jana", "Natalija"));

        int anzahl = mitgliederListe.size();
        System.out.println("#Mitglieder " + anzahl);
    }
}
