package ch05.collections.solutions;

import java.util.Map;

public class MorseCode
{

    public static void main(String[] args)
    {
        System.out.println(toMorseCode("OST"));
        System.out.println(toMorseCode("WEST"));
        System.out.println(toMorseCode("TWEET"));
    }

    static String toMorseCode(String input)
    {
        String result = "";

        for (char letter : input.toCharArray())
        {
            result += convertLetter(letter);
            result += "   ";
        }

        return result.trim();
    }

    private static String convertLetter(char letter)
    {
        var letterToMorseCode = Map.of('E', ".", 'O', "- - -", 'S', ". . .", 'T', "-", 'W', ". - -");

        return letterToMorseCode.getOrDefault(letter, "???");
    }
}
