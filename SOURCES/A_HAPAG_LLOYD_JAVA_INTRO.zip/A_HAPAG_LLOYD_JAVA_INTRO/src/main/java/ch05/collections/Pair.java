package ch05.collections;

import java.util.List;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public final class Pair<T1, T2>
{
    private final T1 first;
    private final T2 second;

    public Pair(final T1 first, final T2 second)
    {
        this.first = first;
        this.second = second;
    }

    public final T1 getFirst()
    {
        return first;
    }

    public final T2 getSecond()
    {
        return second;
    }
    
    public static void main(String[] args)
    {
        Pair<String, List<String>> result = calcComplexResult();
        System.out.println("first: " + result.first);
        System.out.println("second: " + result.second);
        
        
    }
    
    static Pair<String, List<String>> calcComplexResult()
    {
        return new Pair<>("INFO", List.of("VALUE1", "VALUE2"));
    }
}
