package ch04_oo_design.firststeps;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class InterfaceExample
{

    public static void main(String[] args)
    {
        List<String> names = new ArrayList<>();
        List<String> names2 = new LinkedList<>();
        
        for (String name : names)
        {
            names.size();
            names2.size();
        }        
    }

}
