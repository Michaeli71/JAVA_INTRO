package ch04_oo_design.firststeps;

class Base /* extends Object */ {
}

class Sub extends Base {
}

public class SubSub extends Sub 
{
    public static void main(String[] args) 
    {
        Base sub = new Sub();
        Base subsub = new SubSub();

        System.out.println(subsub instanceof Sub);
        System.out.println(subsub instanceof Base);
        System.out.println(sub instanceof Base);
        
        // Typabfrage: Unterschied Compiletyp => Base
        // Laufzeit/Runtime-Typ => getClass()
        System.out.println(sub.getClass());
        System.out.println(subsub.getClass());
        
        Object obj = sub;
        System.out.println(obj.getClass());
        
        Object obj2 = subsub;
        System.out.println(obj2.getClass());       
    }
}