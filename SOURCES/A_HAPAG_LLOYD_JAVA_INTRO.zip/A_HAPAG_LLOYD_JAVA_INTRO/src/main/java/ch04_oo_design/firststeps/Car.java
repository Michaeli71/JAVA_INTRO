package ch04_oo_design.firststeps;

import java.util.List;
import java.util.Objects;

public class Car
{
    String brand;
    String color;
    int horsePower;
    
    // Flag für Tuning Kit
    boolean tunigKitApplied = false;
    
    public Car()
    {
        // Konstruktor-Chaining
        this("unbekannt", "unlackiert", 0);
    }

    public Car(String brand, String color)
    {
        this(brand, color, 0);
    }

    public Car(String brand, String color, int horsePower)
    {
        this.brand = brand;
        this.color = color;
        this.horsePower = horsePower;
    }

    @Override
    public String toString()
    {
        return String.format("Car [brand=%s, color=%s, horsePower=%s]", 
                             brand, color, horsePower);
    }


    void applyTuningKit()
    {
        if (tunigKitApplied)
        {
            System.out.println("Tuning Kit already present, not possible");            
        }
        else
        {
            this.horsePower += 150;
            tunigKitApplied = true;
        }
    }

    void paintWith(String newColor)
    {
        this.color = newColor;
    }

    
    // BÖSER FEHLER: FALSCHE SIGNATUR (PARAMETER-TYPEN)
//    public boolean equals(Car otherCar)
//    {
//        return brand.equals(otherCar.brand);
//    }
    
    


    
    
    public static void main(String[] args)
    {        
        Car myCar = new Car();
        System.out.println(myCar);
        
        myCar.brand = "Audi";
        myCar.color = "Pacific Blue";
        myCar.horsePower = 271;
        System.out.println(myCar);
        
        // nutze neuen Konstruktor
        Car my2ndCar = new Car("Ferrari", "RED", 425);
        System.out.println(my2ndCar);
        
        my2ndCar.paintWith("PURPLE");
        my2ndCar.applyTuningKit();
        System.out.println(my2ndCar);

        my2ndCar.applyTuningKit();
        System.out.println(my2ndCar);
        
        // equals() - semantische Gleichheit
        Car timsCar = new Car("VW", "YELLOW", 123);
        Car jimsCar = new Car("VW", "YELLOW", 123);
        
        System.out.println(timsCar == jimsCar);
        System.out.println(timsCar.equals(jimsCar));
        System.out.println(timsCar.equals("APPLE"));
        System.out.println(timsCar.equals(null));
        
        // 
        Car toSearch = new Car("VW", "YELLOW", 123);
        List<Car> cars = List.of(timsCar, jimsCar, timsCar, jimsCar);
        System.out.println("contains: " + cars.contains(toSearch));
    }

    @Override
    public int hashCode()
    {
        return Objects.hash(brand, color, horsePower, tunigKitApplied);
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Car other = (Car) obj;
        return Objects.equals(brand, other.brand) && Objects.equals(color, other.color)
               && horsePower == other.horsePower;
    }
}
