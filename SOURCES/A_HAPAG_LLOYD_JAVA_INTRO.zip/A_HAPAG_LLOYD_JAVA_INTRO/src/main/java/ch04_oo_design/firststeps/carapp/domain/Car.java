package ch04_oo_design.firststeps.carapp.domain;

import java.util.List;
import java.util.Objects;

public class Car
{
    private String brand;
    String color;
    private int horsePower;
    
    // Flag für Tuning Kit
    boolean tunigKitApplied = false;
    
    public Car()
    {
        // Konstruktor-Chaining
        this("unbekannt", "unlackiert", 0);
    }

    public Car(String brand, String color)
    {
        this(brand, color, 0);
    }

    public Car(String brand, String color, int horsePower)
    {
        this.setBrand(brand);
        this.color = color;
        this.setHorsePower(horsePower);
    }

    @Override
    public String toString()
    {
        return String.format("Car [brand=%s, color=%s, horsePower=%s]", 
                             getBrand(), color, getHorsePower());
    }


    void applyTuningKit()
    {
        if (tunigKitApplied)
        {
            System.out.println("Tuning Kit already present, not possible");            
        }
        else
        {
            this.setHorsePower(this.getHorsePower() + 150);
            tunigKitApplied = true;
        }
    }

    void paintWith(String newColor)
    {
        this.color = newColor;
    }

    
    // BÖSER FEHLER: FALSCHE SIGNATUR (PARAMETER-TYPEN)
//    public boolean equals(Car otherCar)
//    {
//        return brand.equals(otherCar.brand);
//    }
    
    


    
    
    public static void main(String[] args)
    {        
        Car myCar = new Car();
        System.out.println(myCar);
        
        myCar.setBrand("Audi");
        myCar.color = "Pacific Blue";
        myCar.setHorsePower(271);
        System.out.println(myCar);
        
        // nutze neuen Konstruktor
        Car my2ndCar = new Car("Ferrari", "RED", 425);
        System.out.println(my2ndCar);
        
        my2ndCar.paintWith("PURPLE");
        my2ndCar.applyTuningKit();
        System.out.println(my2ndCar);

        my2ndCar.applyTuningKit();
        System.out.println(my2ndCar);
        
        // equals() - semantische Gleichheit
        Car timsCar = new Car("VW", "YELLOW", 123);
        Car jimsCar = new Car("VW", "YELLOW", 123);
        
        System.out.println(timsCar == jimsCar);
        System.out.println(timsCar.equals(jimsCar));
        System.out.println(timsCar.equals("APPLE"));
        System.out.println(timsCar.equals(null));
        
        // 
        Car toSearch = new Car("VW", "YELLOW", 123);
        List<Car> cars = List.of(timsCar, jimsCar, timsCar, jimsCar);
        System.out.println("contains: " + cars.contains(toSearch));
    }

    @Override
    public int hashCode()
    {
        return Objects.hash(getBrand(), color, getHorsePower(), tunigKitApplied);
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Car other = (Car) obj;
        return Objects.equals(getBrand(), other.getBrand()) && Objects.equals(color, other.color)
               && getHorsePower() == other.getHorsePower();
    }

    public String getBrand()
    {
        return brand;
    }

    public void setBrand(String brand)
    {
        this.brand = brand;
    }

    public int getHorsePower()
    {
        return horsePower;
    }

    public void setHorsePower(int horsePower)
    {
        this.horsePower = horsePower;
    }
}
