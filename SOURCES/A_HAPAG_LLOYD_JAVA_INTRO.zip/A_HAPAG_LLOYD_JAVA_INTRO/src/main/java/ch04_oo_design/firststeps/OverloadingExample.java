package ch04_oo_design.firststeps;

// VEREINFACHUNG DER SCHREIBWEISE UND DER AUFRUFE
public class OverloadingExample
{
    public static void main(String[] args)
    {
        OverloadingExample example = new OverloadingExample();

//        example.drawByPosAndSize(1, 2, 3, 4);
//        example.drawFigures("sajsdajha", 3, 4);
          example.draw(1, 2, 3, 4);
          example.draw("sajsdajha", 3, 4);
    }

    
//    void drawFigures(String str, int x, int y)
//    {
//        
//    }
//    
//    void drawByPosAndSize(int x, int y, int w, int h)
//    {
//        
//    }
    
    void draw(String str, int x, int y)
    {
        
    }
    
    void draw(int x, int y, int w, int h)
    {
        
    }

}
