package ch04_oo_design.firststeps.carapp.app;

import ch04_oo_design.firststeps.carapp.domain.Car;

public class CarManagementApp
{
    Car[] availableCars = new Car[] { new Car("Renault", "BLUE", 75), 
                                      new Car("Renault", "PETROL", 175),
                                      new Car("Ferrari", "RED", 455), 
                                      new Car("BMW", "GREEN", 255),
                                      new Car("BMW", "YELLOW", 125),
                                      new Car("VW", "WHITE", 65),
                                      new Car("VW", "BLUE", 105) };

    private CarManagementApp()
    {
    }

    public static void main(String[] args)
    {
        CarManagementApp app = new CarManagementApp();

        System.out.println("Alle Renaults im Angebot:");
        app.filterByBrand("Renault");

        System.out.println();

        System.out.println("Alle Autos mit mehr als 150 PS:");
        app.filterByHorsePowerGreaterThan(150);
    }

    private void filterByBrand(String brand)
    {
        for (Car currentCar : availableCars)
        {
            if (currentCar.getBrand().equals(brand))
                System.out.println(currentCar);
        }
    }

    private void filterByHorsePowerGreaterThan(int minHorsePower)
    {
        for (int i = 0; i < availableCars.length; i++)
        {
            if (availableCars[i].getHorsePower() > minHorsePower)
                System.out.println(availableCars[i]);
        }
    }
}
