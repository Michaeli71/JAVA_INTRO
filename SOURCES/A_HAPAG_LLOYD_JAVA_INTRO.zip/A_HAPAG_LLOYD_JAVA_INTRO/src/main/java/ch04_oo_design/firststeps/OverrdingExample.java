package ch04_oo_design.firststeps;






public class OverrdingExample
{
    static class Base
    {
        void doSomething(String str, int x)
        {
            System.out.println("Base");
        }
    }

    static class Sub extends Base
    {
        @Override
        void doSomething(String str, int x)
        {
            System.out.println("Sub");
        }
    }

    public static void main(String[] args)
    {
        Base b = new Sub();
        b.doSomething("hello", 4711);

    }

}
