package ch04_oo_design.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Counter
{
    public int count = 0;

    public Counter()
    {
    }

    public void setCounter(int count)
    {
        count = count;
    }
}