package ch04_oo_design.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex01_SuperHero
{
    public static void main(String[] args)
    {
        SuperHeroOrig superMan = new SuperHeroOrig("Superman", "Kryptonite-Power", 1_000);
        SuperHeroOrig batMan = new SuperHeroOrig("Batman", "Techno-Power", 100);
        SuperHeroOrig ironMan = new SuperHeroOrig("Ironman", "Techno-Power", 500);
        System.out.println("Superman stronger than Batman? " + superMan.isStrongerThan(batMan));
        System.out.println(SuperHeroOrig.strongestOf(superMan, batMan, ironMan));
    }
}
