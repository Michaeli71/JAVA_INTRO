package ch04_oo_design.solutions;

public class SuperHero
{
    private final String name;
    private final String power; 
    private final int strength;
    
    public SuperHero(String name, String power, int strength)
    {
        this.name = name;
        this.power = power;
        this.strength = strength;
    }

    private boolean isStrongerThan(SuperHero other)
    {
        return strength > other.strength;
    }
    
    private static SuperHero strongestOf(SuperHero superMan, SuperHero batMan, SuperHero ironMan)
    {
        // TODO Auto-generated method stub
        return null;
    }


    
    public static void main(String[] args)
    {
        SuperHero superMan = 
                  new SuperHero("Superman", "Kryptonite-Power", 1_000);
        SuperHero batMan = new SuperHero("Batman", "Techno-Power", 100);
        SuperHero ironMan = new SuperHero("Ironman", "Techno-Power", 500);
        System.out.println("Superman stronger than Batman? " + 
                           superMan.isStrongerThan(batMan));
        //System.out.println(SuperHero.strongestOf(superMan, batMan, ironMan));
    }

    public String getName()
    {
        return name;
    }

    public String getPower()
    {
        return power;
    }

    public int getStrength()
    {
        return strength;
    }
}
