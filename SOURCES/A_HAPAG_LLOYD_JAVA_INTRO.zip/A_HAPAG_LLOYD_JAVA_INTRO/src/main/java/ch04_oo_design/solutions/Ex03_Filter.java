package ch04_oo_design.solutions;

import java.util.List;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex03_Filter
{
    public static void main(String[] args)
    {
        IFilter spamfilter = new SPAMFilter();
        System.out.println(spamfilter.filter(List.of("SPAM", "DAS", "IST", "SPAM", "SPAM", "DETECTED")));
    
        IFilter namefilter = new NameFilter(List.of("MICHAEL", "SOPHIE"));
        System.out.println(namefilter.filter(List.of("DAS", "SIND", "MICHAEL", "UND", "SOPHIE")));
    }
}

interface IFilter
{
    public List<String> filter(List<String> values);
}

class ExcludeFilter implements IFilter
{
    List<String> blocked = List.of();

    ExcludeFilter(List<String> blocked)
    {
        this.blocked = blocked;
    }

    @Override
    public List<String> filter(List<String> values)
    {
        return values.stream().filter(val -> !blocked.contains(val)).toList();
    }
}

class IncludeFilter implements IFilter
{
    List<String> included = List.of();

    IncludeFilter(List<String> included)
    {
        this.included = included;
    }

    @Override
    public List<String> filter(List<String> values)
    {
        return values.stream().filter(val -> included.contains(val)).toList();
    }
}

final class SPAMFilter extends ExcludeFilter
{
    SPAMFilter()
    {
        super(List.of("SPAM"));
    }
}

final class NameFilter extends IncludeFilter
{
    NameFilter(List<String> names)
    {
        super(names);
    }
}