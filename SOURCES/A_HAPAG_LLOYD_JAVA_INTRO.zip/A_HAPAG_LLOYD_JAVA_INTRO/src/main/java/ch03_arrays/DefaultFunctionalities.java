package ch03_arrays;

import java.util.Arrays;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class DefaultFunctionalities
{
    public static void main(String[] args)
    {
        int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

        reverse(numbers, 2, 7);
        System.out.println(Arrays.toString(numbers));

        int[][] values = { { 1, 1, 1, 1 }, 
                           { 2, 2, 2, 2 }, 
                           { 3, 3, 3, 3 }, 
                           { 4, 4, 4, 4 } };
        print2dArray(values);
        int[][] rotated1 = rotate(values, false);
        print2dArray(rotated1);
        int[][] rotated2 = rotate(rotated1, false);
        print2dArray(rotated2);
        int[][] rotated3 = rotate(rotated2, true);
        print2dArray(rotated3);
    }

    public static void swap(int[] values, int first, int second)
    {
        final int value1 = values[first];
        final int value2 = values[second];
        values[first] = value2;
        values[second] = value1;
    }

    public static void reverse(final int[] values, int start, int end)
    {
        while (start < end)
        {
            swap(values, start, end);
            start++;
            end--;
        }
    }

    public static int[][] rotate(int[][] values, boolean rotateLeft)
    {
        int maxX = values[0].length - 1;
        int maxY = values.length - 1;
        
        final int[][] rotatedArray = new int[values[0].length][values.length];
        for (int y = 0; y <= maxY; y++)
        {
            for (int x = 0; x <= maxX; x++)
            {
                int origValue = values[y][x];
                if (rotateLeft)
                {
                    rotatedArray[maxX - x][y] = origValue;
                }
                else
                {
                    rotatedArray[x][maxY - y] = origValue;
                }
            }
        }
        return rotatedArray;
    }

    public static void print2dArray(int[][] values)
    {
        for (int y = 0; y < values.length; y++)
        {
            for (int x = 0; x < values[y].length; x++)
            {
                System.out.print(values[y][x]);
            }
            System.out.println();
        }
    }
}
