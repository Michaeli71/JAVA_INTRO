package ch03_arrays;

import java.util.Arrays;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class SwapExample
{
    public static void main(String[] args)
    {
        int[] values = { 1, 2, 7, 4, 5, 3 };
        swap(values, 2, 5);
        
        System.out.println(Arrays.toString(values));
        
        int[] valuesToReverse = { 7, 6, 5, 4, 3, 2, 1 };
        int[] result = reverse(valuesToReverse);
        System.out.println(Arrays.toString(result));
        int[] result2 = reverse(result);
        System.out.println(Arrays.toString(result2));
    }
    
    // 1. Kopie
    // 2. alle Elemente in umgekehrter Reihenfolge
    private static int[] reverse(int[] valuesToReverse)
    {
        int[] result = Arrays.copyOf(valuesToReverse, valuesToReverse.length);
        
        for (int i = 0; i < result.length / 2; i++)
        {
            swap(result, i, result.length -1 - i);
        }   
        return result;
    }



    public static void swap(int[] values, int first, int second)
    {
        final int value1 = values[first];
        final int value2 = values[second];
        
        values[first] = value2;
        values[second] = value1;
    }   
}
