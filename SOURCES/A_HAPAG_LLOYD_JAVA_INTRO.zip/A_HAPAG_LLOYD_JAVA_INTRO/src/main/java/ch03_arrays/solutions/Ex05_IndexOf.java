package ch03_arrays.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex05_IndexOf
{
    public static void main(String[] args)
    {
        int[] values = { 1, 2, 3, 4, 7, 2, 3, 2 };
    
        System.out.println(indexOf(values, 2));
        System.out.println(indexOf(values, 2, 2));
        System.out.println(indexOf(values, 2, 2, 4));
        System.out.println(lastIndexOf(values, 2));
    }

    static int indexOf(final int[] values, final int searchFor)
    {
        return indexOf(values, searchFor, 0, values.length);
    }

    static int indexOf(final int[] values, final int searchFor, int startIdx)
    {
        return indexOf(values, searchFor, startIdx, values.length);
    }
    
    static int indexOf(final int[] values, final int searchFor, int startIdx, int endIdx)
    {
        for (int pos = startIdx; pos < endIdx; pos++)
        {
            if (values[pos] == searchFor)
                return pos;
        }
        return -1;
    }
    
    // DRY => Don't repeat yourself
    // !DRY => WET => man steht im Regen => an zig Stellen ändern => schlecht              
    
    static int lastIndexOf(final int[] values, final int searchFor)
    {
        for (int pos = values.length - 1; pos >= 0; pos--)
        {
            if (values[pos] == searchFor)
                return pos;
        }
        return -1;
    }
}
