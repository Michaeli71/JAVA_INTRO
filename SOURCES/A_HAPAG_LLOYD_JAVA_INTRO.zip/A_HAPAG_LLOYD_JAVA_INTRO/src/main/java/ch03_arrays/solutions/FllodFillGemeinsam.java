package ch03_arrays.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class FllodFillGemeinsam
{
    // START: 16:02 => 16:14
    public static void main(String[] args)
    {
        char[][] world = createWorld();

        print2darray(world);
        floodfill(world, 5, 5, '+');
        print2darray(world);
                
        char[][] world2 = createWorld();
        char[][] pattern = { { '-', '-', '-'},
                             { '+', '+', '+'},
                             { '*', '*', '*'} };
        
        print2darray(world2);
        floodfill_with_pattern(world2, 1, 1, pattern);
        print2darray(world2);
    }

    private static char[][] createWorld()
    {
        char[][] world = { "xxxxxxxxxxxxxxxxx".toCharArray(),
                           // char[] = { "x", "x", ... "x"}
                           "x        xxxxx  x".toCharArray(),
                           "xxx    xxxxx    x".toCharArray(),
                           "xxx xxxxxxxxxx  x".toCharArray(),
                           "x               x".toCharArray(),
                           "x         xxxxxx".toCharArray(),
                           "x         xx".toCharArray(),
                           "x         xx".toCharArray(),
                           "x         xx".toCharArray(),
                           "xxx xxxxxxxx".toCharArray(),
                           "xxx      xxx".toCharArray(),
                           "xxxxx      x".toCharArray(),
                           "xxxxxxxxxxxx".toCharArray() };
        return world;
    }

    private static void floodfill_with_pattern(char[][] world, int x, int y, char[][] pattern)
    {
        // Sind wir noch im Spielfeld?
        if (y < 0 || y > world.length || x < 0 || x > world[y].length)
            return;
            
        // ist es ein gefülltes Feld?
        if (world[y][x] != ' ')
            return;
                       
        // ist es ein Leerfeld?
        if (world[y][x] == ' ')
        {
            // WAS MAVHE ICH HIER?
            world[y][x] = getFillChar(pattern, x, y);
            
            floodfill_with_pattern(world, x + 1, y, pattern);
            floodfill_with_pattern(world, x - 1, y, pattern);
            floodfill_with_pattern(world, x, y - 1, pattern);
            floodfill_with_pattern(world, x, y + 1, pattern);
        }
    }
        
    private static char getFillChar(char[][] pattern, int x, int y)
    {     
        int height = pattern.length;
        int width = pattern[0].length;
        
        return pattern[y % height][x % width];
    }

    private static void floodfill(char[][] world, int x, int y, char fillChar)
    {
        // Sind wir noch im Spielfeld?
        if (y < 0 || y > world.length || x < 0 || x > world[y].length)
            return;
            
        // ist es ein gefülltes Feld?
        if (world[y][x] != ' ')
            return;
                       
        // ist es ein Leerfeld?
        if (world[y][x] == ' ')
        {
            world[y][x] = fillChar;
            
            floodfill(world, x + 1, y, fillChar);
            floodfill(world, x - 1, y, fillChar);
            floodfill(world, x, y - 1, fillChar);
            floodfill(world, x, y + 1, fillChar);
        }
    }

    private static void print2darray(char[][] world)
    {
        for (int y = 0; y < world.length; y++)
        {
            for (int x = 0; x < world[y].length; x++)
            {
                System.out.print(world[y][x]);
            }
            System.out.println();
        }
    }
}
