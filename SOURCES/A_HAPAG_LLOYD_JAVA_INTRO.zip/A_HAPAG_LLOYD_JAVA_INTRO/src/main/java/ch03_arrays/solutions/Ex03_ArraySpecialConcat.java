package ch03_arrays.solutions;

import java.util.Arrays;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex03_ArraySpecialConcat
{
    public static void main(String[] args)
    {
        String[] first = { "neue", "Array", "Funktion" };
        String[] second = { "Dies", "ist", "eine" };
    
        String[] result = arraySpecialConcat(first, second);
        System.out.println(Arrays.toString(result));
        
        String[] result2 = arraySpecialConcat(second, first);
        System.out.println(Arrays.toString(result2));
    }

    static String[] arraySpecialConcat(String[] values1, String[] values2)
    {
        int length1 = values1.length;
        int length2 = values2.length;

        int pos = 0;

        String[] result = new String[length1 + length2];

        for (int i = 0; i < length2; i++)
        {
            result[pos] = values2[i];
            pos++;
        }

        for (int i = 0; i < length1; i++)
        {
            result[pos] = values1[i];
            pos++;
        }

        return result;
    }
}
