package ch03_arrays.solutions;

import java.util.Arrays;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex01_ArrayShuffle
{
    public static void main(String[] args)
    {
        int[] sorted = { 1, 2, 3, 4, 5, 6, 7};
        shuffle(sorted);
        System.out.println(Arrays.toString(sorted));
        
        int[] primes = { 2, 3, 5, 7, 11, 13};
        shuffle(primes);
        System.out.println(Arrays.toString(primes));
        
        int[] numbers = new int[100_000];
        for (int i = 0; i < numbers.length; i++)
            numbers[i] = i;
        
        // TRICK: Auf handhabbare Größe beschrönken
        System.out.println(Arrays.toString(Arrays.copyOf(numbers, 20)));        
        shuffle(numbers);
        System.out.println(Arrays.toString(Arrays.copyOf(numbers, 20)));                       
    }

    static void shuffle(int[] values)
    {
        int maxShuffle = Math.max(10, values.length / 2);
        for (int run = 0; run < maxShuffle; run++)
        {
            int pos1 = (int) (Math.random() * values.length);
            int pos2 = (int) (Math.random() * values.length);
            
            swap(values, pos1, pos2);
        }
    }

    public static void swap(final int[] values, final int first, final int second)
    {
        final int tmp = values[first];
        values[first] = values[second];
        values[second] = tmp;
    }
}
