package ch03_arrays.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex07_FloodFill
{
    public static void main(String[] args)
    {
        char[][] world = { "/----------------/".toCharArray(), "/--           ---/".toCharArray(),
                           "/--    ###    ---/".toCharArray(), "/--   #   #     -/".toCharArray(),
                           "/--   #   #     -/".toCharArray(), "/--    ###    ---/".toCharArray(),
                           "/--           ---/".toCharArray(), "/---------------/".toCharArray(), };

        floodFill(world, 5, 1);
        printWorld(world);

        char[][] world2 = { "/-------           --------/".toCharArray(), "/--               #     ---/".toCharArray(),
                            "/--               #     ---/".toCharArray(), "/--               #     ---/".toCharArray(),
                            "/--    ###       # #     ---/".toCharArray(),
                            "/--   #   #      #  #      -/".toCharArray(),
                            "/--   #   #       ###      -/".toCharArray(),
                            "/--    ###    ##         ---/".toCharArray(),
                            "/--          #  #         ---/".toCharArray(),
                            "/--          #  #         ---/".toCharArray(),
                            "/-------------------------/".toCharArray(), };

        char[][] pattern = { ".+.".toCharArray(), "+o+".toCharArray(), "$+$".toCharArray(), "+o+".toCharArray() };

        floodFill(world2, 5, 1, pattern);
        printWorld(world2);
    }

    private static void printWorld(char[][] world)
    {
        for (char[] line : world)
        {
            //System.out.println(Arrays.toString(line));
            for (char ch : line)
                System.out.print(ch);

            System.out.println();
        }
    }

    void print2dArray(int[][] values)
    {
        for (int y = 0; y < values.length; y++)
        {
            for (int x = 0; x < values[y].length; x++)
            {
                System.out.print(values[y][x]);
            }
            System.out.println();
        }
    }
    
    static void floodFill(char[][] values, int x, int y)
    {
        if (x < 0 || y < 0 || y >= values.length || x >= values[y].length)
            return;

        if (values[y][x] == ' ')
        {
            values[y][x] = '*';

            floodFill(values, x, y - 1);
            floodFill(values, x + 1, y);
            floodFill(values, x, y + 1);
            floodFill(values, x - 1, y);
        }
    }

    static void floodFill(char[][] values, int x, int y, char[][] pattern)
    {
        if (x < 0 || y < 0 || y >= values.length || x >= values[y].length)
            return;

        if (values[y][x] == ' ')
        {
            values[y][x] = findFillChar(x, y, pattern);

            floodFill(values, x, y - 1, pattern);
            floodFill(values, x + 1, y, pattern);
            floodFill(values, x, y + 1, pattern);
            floodFill(values, x - 1, y, pattern);
        }
    }

    static char findFillChar(int x, int y, char[][] pattern)
    {
        final int maxY = pattern.length;
        final int maxX = pattern[0].length;

        return pattern[y % maxY][x % maxX];
    }
}
