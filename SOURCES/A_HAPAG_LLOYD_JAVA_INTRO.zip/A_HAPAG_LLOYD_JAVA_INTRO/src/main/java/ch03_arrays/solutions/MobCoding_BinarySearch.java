package ch03_arrays.solutions;

import java.util.Arrays;

public class MobCoding_BinarySearch
{

    public static void main(String[] args)
    {
        int size = 10_000_000;
        int[] values = new int[size];
        for (int i = 0; i < values.length; i++)
        {
            values[i] = i;
        }
        
        // "primitive" / lineare Suche von vorne nach hinten
        int desiredValue = -4711;
        int foundPos = -1;
        for (int i = 0; i < values.length; i++)
        {
            if (values[i] == desiredValue)
            {
                foundPos = i;
                break;
            }
        }
        
        if (foundPos != -1)
        {
            System.out.println("Found " + desiredValue + " at pos " + foundPos);
        }
        else
        {
            System.out.println(desiredValue + " NOT FOUND!");
        }
        
        
        // Binärsuche mit Ausschluss jeweils der unpassenden Hälfte
        boolean found = binarySearch(values, desiredValue);
        System.out.println("found: " + found);
    }

    // ACHTUNG: arbeitet nur korrekt auf sortierten Daten
    // ACHTUNG: wir kopieren hier noch viele Arrays => besser mit Positionszeigern arbeiten
    private static boolean binarySearch(int[] values, int desiredValue)
    {
        // rekusiven Abbruch 
        if (values.length == 0)
            return false;
        
        int midPos = values.length / 2;
        int midValue = values[midPos];
        
        if (midValue == desiredValue)
            return true;
        
        // rekursiven Abstieg
        if (midValue < desiredValue)
        {
            // suche "oben"
            int[] upperPart = Arrays.copyOfRange(values, midPos + 1, values.length);
            return binarySearch(upperPart, desiredValue);
        }
        if (midValue > desiredValue)
        {
            // suche "unten"
            int[] lowerPart = Arrays.copyOfRange(values, 0, midPos);
            return binarySearch(lowerPart, desiredValue);
        }
        
        return false;
    }
}
