package ch03_arrays.solutions;

import java.util.Arrays;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex04_ArrayPalindrome
{
    public static void main(String[] args)
    {
        int[] values1 = { 1, 2, 3, 4, 3, 2, 1};
        int[] values2 = { 1, 2, 3, 4, 5, 2, 1};
        int[] values3 = { 1, 2, 2, 1}; 

        System.out.println(isPalindrome(values1));
        System.out.println(isPalindrome(values2));
        System.out.println(isPalindrome(values3));
        
        System.out.println(isPalindromeRec(values1));
        System.out.println(isPalindromeRec(values2));
        System.out.println(isPalindromeRec(values3));
    }

    private static boolean isPalindrome(int[] values)
    {
        int left = 0;
        int right = values.length - 1;
        
        while (left < right && values[left] == values[right])
        {
            left++;
            right--;
        }
        
        return left >= right;
    }
    
    private static boolean isPalindromeRec(int[] values)
    {
        if (values.length <= 1) 
            return true;
                      
        int left = 0;
        int right = values.length - 1;
        
        if (values[left] == values[right])
        {
            int[] shrinkedArray = Arrays.copyOfRange(values, left + 1, right);
            return isPalindromeRec(shrinkedArray);
        }
        
        return false;
    }
    
    private static boolean isPalindromeRecCommented(int[] values)
    {
        // rekursiver Abbruch
        //if (values.length == 0 || values.length == 1)
        if (values.length <= 1) // Achtung: im Allgemeinen nicht gleichwertig bei negativen Werten
            return true;
                      
        int left = 0;
        int right = values.length - 1;
        
        if (values[left] == values[right])
        {
            // verkleinert prüfen
            // ACHTUNG: FALLSTRICK ++ / -- würde den Parameter nicht ändern
            // ACHTUNG: Nur zur Demonstration von copyOfRange(), nicht optimale Lösung
            // => Abhilfe Positionszeiger, wie in "Java Challenge" beschrieben
            int[] shrinkedArray = Arrays.copyOfRange(values, left + 1, right);
            return isPalindromeRecCommented(shrinkedArray);
        }
        
        return false;
    }
}
