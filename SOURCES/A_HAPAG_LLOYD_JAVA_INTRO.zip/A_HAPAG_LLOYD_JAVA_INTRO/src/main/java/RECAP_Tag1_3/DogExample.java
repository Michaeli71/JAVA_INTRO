package RECAP_Tag1_3;

/*
 * Schreiben Sie eine Klasse namens Dog mit Attributen für Rasse, Alter und Farbe. 
 * Außerdem kann ein Hund bellen, schlafen und fressen. Erstellen Sie passende Methoden 
 * (mit Konsolenausgaben).
Überprüfen Sie Ihre Implementierung mit folgendem Ablauf:
 */
public class DogExample
{
    public static void main(String[] args)
    {
        var collie = new Dog("Collie", 11, "tricolor");
        collie.sleep();

        var boxer = new Dog("Boxer", 7, "brown");
        boxer.eat();

        var germanShepherd = new Dog("German Shepherd", 3, "black/brown");
        germanShepherd.bark();
        
        // 
        var collie2 = new Dog("Collie", 11, "tricolor");
        
        System.out.println(collie.equals(collie2));
    }
}
