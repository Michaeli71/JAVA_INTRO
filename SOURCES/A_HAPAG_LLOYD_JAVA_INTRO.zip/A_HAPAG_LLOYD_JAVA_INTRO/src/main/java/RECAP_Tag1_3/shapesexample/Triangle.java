package RECAP_Tag1_3.shapesexample;

public class Triangle extends Shape
{
    private Point p1;
    private Point p2; 
    private Point p3;

    public Triangle(Point p1, Point p2, Point p3)
    {
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
    }  
        
    public Triangle(int p1x, int p1y, int p2x, int p2y, int p3x, int p3y)
    {
        this(new Point(p1x, p1y), new Point(p2x, p2y), new Point(p3x, p3y));
    }
    
    @Override
    public void draw()
    {
        System.out.println("Drawing triangle");
        System.out.println("at " + p1.getX() + ", " + p1.getY());
        System.out.println("at " + p2.getX() + ", " + p2.getY());
        System.out.println("at " + p3.getX() + ", " + p3.getY());
    }

    @Override
    public void moveBy(int dx, int dy)
    {
        p1.moveBy(dx, dy); 
        p2.moveBy(dx, dy);
        p3.moveBy(dx, dy); 
    }
}
