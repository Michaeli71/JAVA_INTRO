package RECAP_Tag1_3.shapesexample;

public class Circle extends Shape
{
    private Point midPoint;
    private int radius;
    
    public Circle(Point midPoint, int radius)
    {
        this.midPoint = midPoint;
        this.radius = radius;
    }

    public Circle(int midPointX, int midPointY, int radius)
    {
        this(new Point(midPointX, midPointY), radius);
    }

    @Override
    public void draw()
    {
        System.out.println("Draw circle at " + midPoint.getX() + ", " + midPoint.getY() + " with radius " + radius);
    }

    @Override
    public void moveBy(int dx, int dy)
    {
        midPoint.moveBy(dx, dy);
    }
}
