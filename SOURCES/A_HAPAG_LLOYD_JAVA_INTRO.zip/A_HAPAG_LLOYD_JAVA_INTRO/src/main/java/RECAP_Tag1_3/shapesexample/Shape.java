package RECAP_Tag1_3.shapesexample;

/*
 * Schreiben Sie eine Basisklasse namens Shape. Diese soll die Subklassen 
 * für Punkte, Dreiecke und Kreise (ggf. auch noch Quadrate) besitzen. 
 * Jede Klasse soll die zwei Methoden namens draw() und moveBy(int dx, int dy) 
 * bereitstellen. Denken Sie an Polymorphismus sowie die Möglichkeit, 
 * Klassen wiederzuverwenden, etwa für die Eckpunkte von Figuren.
 */
// bei komplett abstrkter Klasse => interface
public abstract class Shape  // => später ggf. interface
{
    public abstract void draw();
    
    public abstract void moveBy(int dx, int dy);
    
    
    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
    }
}
