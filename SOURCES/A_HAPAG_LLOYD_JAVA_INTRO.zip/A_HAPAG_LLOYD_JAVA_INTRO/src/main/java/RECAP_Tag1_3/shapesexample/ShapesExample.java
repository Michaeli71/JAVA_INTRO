package RECAP_Tag1_3.shapesexample;

import java.util.List;

public class ShapesExample
{
    public static void main(String[] args)
    {
        var point = new Point(7, 2);
        point.draw();
        System.out.println(point);

        point.moveBy(4, 5);
        point.draw();
        System.out.println(point);

        var triangle = new Triangle(new Point(5, 1), new Point(7, 4), new Point(2, 7));
        triangle.draw();

        triangle.moveBy(3, 3);
        triangle.draw();

        var circle = new Circle(new Point(11, 11), 7);
        circle.draw();

        circle.moveBy(-4, -4);
        circle.draw();
        
        
        System.out.println("-------------------------------");
        var polygon = new Polygon(List.of(new Point(5, 1), new Point(7, 4), new Point(2, 7)));
        polygon.draw();
        
        // PO / Michael: Ich möchte mehrere Punkte hinzufügen können
        polygon.addPoint(new Point(10, 10));
        polygon.addPoint(new Point(12, 8));
        polygon.draw();
        
        polygon.removePoint(new Point(2, 7));
        polygon.draw();
    }
}
