package RECAP_Tag1_3.shapesexample;

import java.util.ArrayList;
import java.util.List;

public class Polygon extends Shape
{
    private List<Point> points;

    public Polygon(List<Point> points)
    {
        // Entkopplung
        this.points = new ArrayList<>(points);
    }  
    
    @Override
    public void draw()
    {
        System.out.println("Drawing polygon");
        for (Point currentPoint : points)
        {
            System.out.println("at " + currentPoint.getX() + ", " + currentPoint.getY());
        }
    }

    @Override
    public void moveBy(int dx, int dy)
    {
        for (Point currentPoint : points)
        {
            currentPoint.moveBy(dx, dy); 
        }
    }

    public void addPoint(Point point)
    {
        points.add(point);        
    }

    public void removePoint(Point point)
    {
        points.remove(point);        
    }
}
