package RECAP_Tag1_3;

import java.time.LocalDate;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex09_CarExample
{
    static class Car
    {
        private String brand;

        private int    speed;

        private int    maxSpeed;


        public Car(String brand, int speed, int maxSpeed)
        {
            this.brand = brand;
            this.speed = speed;
            this.maxSpeed = maxSpeed;
        }

        public void accelerate(int speedBumb)
        {
            System.out.println("Car acceleracte");

            if (speed < maxSpeed)
            {
                speed += speedBumb;
                if (speed > maxSpeed)
                    speed = maxSpeed;
            }

            // Alternative:
            speed = Math.min(speed, maxSpeed);
        }

        public void slowDown()
        {
            System.out.println("Car slow down");
            if (speed > 0)
                speed -= 10;

            speed = Math.max(speed, 0);
        }

        public void move()
        {
            if (speed > 0)
                System.out.println("Car moving with " + speed + " km/h");
            else
                System.out.println("Car stands still");
        }
    }

    static class Driver
    {
        private String name;

        private Car    car;

        public Driver(String name, Car car)
        {
            this.name = name;
            this.car = car;
        }

        void drive()
        {
            car.move();
        }

        void brake()
        {
            car.slowDown();
        }

        void speedPedalDown()
        {
            car.accelerate(20);
        }

        void speedPedalKickStart()
        {
            car.accelerate(50);
        }

        void changeCar(Car car)
        {
            this.car = car;
        }
        
        
        
        /* ACHTUNG zirkuläre Referenz ...
        @Override
        public String toString()
        {
            return String.format("Driver [name=%s, car=%s, license=%s]", name, car, license);
        }
        */
        @Override
        public String toString()
        {
            return String.format("Driver [name=%s, car=%s, license=%s]", name, car, license.validSince);
        }

        // Kür
        DrivingLicense license;
        
        public void setLicense(DrivingLicense license)
        {
            this.license = license;            
        }

        public void loseLicsens()
        {
            this.license = null;
        }

        public void showLicense()
        {
           if (license != null)
               System.out.println(license);
           else
               System.out.println("UUPS: I lost my license and are not allowed to drive");
        }
    }

    public static void main(String[] args)
    {
        var audi = new Car("Audi", 0, 220);
        var driver = new Driver("Michael", audi);
        driver.drive();
        driver.speedPedalKickStart();
        driver.drive();
        driver.speedPedalDown();
        driver.drive();
    
        driver.brake();
        driver.brake();
        driver.brake();
    
        var vw = new Car("VW", 0, 120);
        driver.changeCar(vw);
        driver.speedPedalDown();
        driver.drive();
        
        
        // Kür
        var license = new DrivingLicense(driver, LocalDate.of(1990, 5, 18), "Syke");
        driver.setLicense(license);        
        driver.showLicense();
        driver.loseLicsens();
        driver.showLicense();
    }
    
    // Kür 
    static class DrivingLicense
    {
        private final Driver assignedTo;
        private final LocalDate validSince;
        private final String city;
        
        public DrivingLicense(Driver assignedTo, LocalDate validSince, String city)
        {
            this.assignedTo = assignedTo;
            this.validSince = validSince;
            this.city = city;
        }

        /*
        @Override
        public String toString()
        {
            return String.format("DrivingLicense [assignedTo=%s, validSince=%s, city=%s]", assignedTo, validSince,
                                 city);
        }
        */
        
        @Override
        public String toString()
        {
            return String.format("DrivingLicense [assignedTo=%s, validSince=%s, city=%s]", assignedTo.name, validSince,
                                 city);
        }
    }
}
