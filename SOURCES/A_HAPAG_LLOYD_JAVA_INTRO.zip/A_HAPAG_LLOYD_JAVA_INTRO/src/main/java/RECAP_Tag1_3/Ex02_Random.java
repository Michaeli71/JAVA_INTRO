package RECAP_Tag1_3;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex02_Random
{
    public static void main(String[] args)
    {
        rollUntil6();
        rollUntil6_Twice();
    }

    private static void rollUntil6()
    {
        boolean got6 = false;
        int trys = 0;
                
        while (!got6)
        {
            trys++;
            int number = 1 + (int) (Math.random() * 6);
            System.out.println(number);
            got6 = number == 6;
        }
        
        System.out.println("#trys: " + trys);
    }
    
    private static void rollUntil6_Twice()
    {
        boolean gotFirst6 = false;
        boolean gotSecond6 = false;
        int trys = 0;
                
        while (!gotFirst6 || !gotSecond6)
        {
            trys++;
            int number = rollDice();
            if (number == 6)
            {
                if (!gotFirst6)
                {
                    System.out.println("gotFirst6 with " + trys);
                    gotFirst6 = true;
                }
                else if (gotFirst6 && !gotSecond6)
                {
                    System.out.println("gotSecond6 with " + trys);
                    gotSecond6 = true;
                }
            }
        }
    }

    private static int rollDice()
    {
        return 1 + (int) (Math.random() * 6);
    }
}
