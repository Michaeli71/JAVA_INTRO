package RECAP_Tag1_3;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex04_SwearwordsEraser
{
    public static void main(String[] args)
    {
        String[] wordsToErase = { "Dreck", "Mist", "Scheiss" };

        String input = "Was für ein Dreck Mist Wetter in Kiel. Scheiss nasskalter Regen.";

        System.out.println(eraseWords(input, wordsToErase));
    }

    private static String eraseWords(String input, String[] wordsToErase)
    {
        String result = input;

        for (String word : wordsToErase)
        {
            result = result.replaceAll(word, " - PIEP - ");
        }

        return result;
    }

}
