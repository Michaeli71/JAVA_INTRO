package RECAP_Tag1_3;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex03_PowerOf
{
    public static void main(String[] args)
    {
        System.out.println(powerOf(4, 2));
        System.out.println(powerOf(4, 3));
        System.out.println(powerOf(8, 2));
        System.out.println(powerOf(8, 3));
        System.out.println(powerOf(8, 4));
        System.out.println(powerOf(16, 2));
        System.out.println(powerOf(16, 3));
        
        System.out.println("-------------------");
        
        System.out.println(powerOfIterative(4, 2));
        System.out.println(powerOfIterative(4, 3));
        System.out.println(powerOfIterative(8, 2));
        System.out.println(powerOfIterative(8, 3));
        System.out.println(powerOfIterative(16, 0));
        System.out.println(powerOfIterative(16, 1));
        
        System.out.println("-------------------");
                
        System.out.println(powerOfOptimized(4, 2));
        System.out.println(powerOfOptimized(4, 3));
        System.out.println(powerOfOptimized(8, 2));
        System.out.println(powerOfOptimized(8, 3));
        System.out.println(powerOfOptimized(16, 0));
        System.out.println(powerOfOptimized(16, 1));        
    }

    static int powerOf(int x, int y)
    {
        if (y == 0)
            return 1;
        if (y == 1)
            return x;

        return powerOf(x, y - 1) * x;
    }
    
    static int powerOfIterative(int x, int y)
    {
        if (y == 0)
            return 1;
        
//        if (y == 1)
//            return x;

        int result = x;
        for (int i = 1; i < y; i++)
        {
            result *= x;
        }
        return result;
    }
    
    static int powerOfOptimized(int x, int y)
    {
        if (y == 0)
            return 1;
        if (y == 1)
            return x;
    
        int result = powerOfOptimized(x * x, y / 2);
        if (y % 2 == 1)
           return x * result; 
        return result;
    }
}
