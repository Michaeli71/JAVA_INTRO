package RECAP_Tag1_3;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex08_ShapesExample
{
    static abstract class Shape
    {
        abstract void draw();
        abstract void moveBy(int dx, int dy);
    }

    static class Point extends Shape
    {
        int x;
        int y;
        
        public Point(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        @Override
        void draw()
        {
            System.out.println("Drawing Point at " + x + " / " + y);            
        }

        @Override
        void moveBy(int dx, int dy)
        {
            x += dx;
            y += dy;            
        }

        @Override
        public String toString()
        {
            return String.format("Point [x=%s, y=%s]", x, y);
        }
    }
    
    static class Triangle extends Shape
    {
        Point p1;
        Point p2;
        Point p3;
               
        public Triangle(Point p1, Point p2,
                        Point p3)
        {
            this.p1 = p1;
            this.p2 = p2;
            this.p3 = p3;
        } 
        
        @Override
        void draw()
        {
            System.out.println("Drawing Triangle");   
            System.out.println(p1);
            System.out.println(p2);
            System.out.println(p3);           
        }

        @Override
        void moveBy(int dx, int dy)
        {
            p1.moveBy(dx, dy);
            p2.moveBy(dx, dy);
            p3.moveBy(dx, dy);
        }
    }
    
    static class Circle extends Shape
    {
        Point midpoint;
        int radius;
               
        public Circle(Point midpoint, int radius)
        {
            this.midpoint = midpoint;
            this.radius = radius;
        } 
        
        @Override
        void draw()
        {
            System.out.println("Drawing Circle with radius " + radius);   
            System.out.println(midpoint);
         
        }

        @Override
        void moveBy(int dx, int dy)
        {
            midpoint.moveBy(dx, dy);
        }
    }
    
    
    static class Rectangle extends Shape
    {
        Point lo;
        Point ro;
        Point lu;
        Point ru;
                       
        @Override
        void draw()
        {
            System.out.println("Drawing Rectangle");      
            System.out.println(lo);
            System.out.println(ro);
            System.out.println(lu);
            System.out.println(ru);   
        }

        @Override
        void moveBy(int dx, int dy)
        {
            /*
            lo.moveBy(dx, dy);
            ro.moveBy(dx, dy);
            lu.moveBy(dx, dy);
            ru.moveBy(dx, dy);
            */
            
            // Trick
            Point[] edgePoints = { lo, ro, lu, ru };
            for (Point point : edgePoints)
                point.moveBy(dx, dy);
        }
    }
    
    
    public static void main(String[] args)
    {
        var point = new Point(7, 2);
        point.draw();
        System.out.println(point);
        
        point.moveBy(4, 5);
        point.draw();
        System.out.println(point);   

        
        var triangle = new Triangle(new Point(5, 1), new Point(7, 4), new Point(2, 7));
        triangle.draw();
        
        triangle.moveBy(3, 3);
        triangle.draw();
        
        
        var circle = new Circle(new Point(11, 11), 7);
        circle.draw();
        
        circle.moveBy(-4, -4);
        circle.draw();
    }
}
