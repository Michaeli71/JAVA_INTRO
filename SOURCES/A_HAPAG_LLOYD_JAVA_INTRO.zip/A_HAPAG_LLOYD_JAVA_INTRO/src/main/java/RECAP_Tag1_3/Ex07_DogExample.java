package RECAP_Tag1_3;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex07_DogExample
{
    static class Dog
    {
        private String breed;

        private int    age;

        private String coatColor;

        public Dog(String breed, int age, String coatColor)
        {
            this.breed = breed;
            this.age = age;
            this.coatColor = coatColor;
        }

        public void bark()
        {
            System.out.println("barking");
        }

        public void sleep()
        {
            System.out.println("sleeping");
        }

        public void eat()
        {
            System.out.println("eating");
        }
    }

    public static void main(String[] args)
    {
        var collie = new Dog("Collie", 11, "tricolor");
        collie.sleep();
        var boxer = new Dog("Boxer", 7, "brown");
        boxer.eat();
        var germanShepherd = new Dog("German Shepherd", 3, "black/brown");
        germanShepherd.bark();
    }
}
