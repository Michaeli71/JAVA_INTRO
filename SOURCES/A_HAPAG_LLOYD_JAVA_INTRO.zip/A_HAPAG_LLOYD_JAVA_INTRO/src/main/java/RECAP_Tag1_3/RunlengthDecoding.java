package RECAP_Tag1_3;

/*
 * "A1B2C3D4E5"

bedeutet also 1 x A, 2 x B, 3 x C, 4 x D und 5 x E:

"ABBCCCDDDDEEEEE"
 */
public class RunlengthDecoding
{
    public static void main(String[] args)
    {
        System.out.println(decode("A1B2C3D4E5"));
        
        System.out.println(decode("110213041506170819"));
    }

    private static String decode(String input)
    {
        String result = "";    
    
        for (int i = 0; i < input.length(); i += 2)
        {
            String currentChar = input.substring(i, i + 1);
            String currentCount = input.substring(i + 1, i + 2);
            
            int repeatCount = Integer.valueOf(currentCount);
            
            result += currentChar.repeat(repeatCount);
        }
        return result;
    }
}
