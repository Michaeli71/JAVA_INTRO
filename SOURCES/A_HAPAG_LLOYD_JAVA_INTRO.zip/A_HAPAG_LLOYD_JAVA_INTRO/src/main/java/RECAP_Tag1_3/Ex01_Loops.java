package RECAP_Tag1_3;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex01_Loops
{
    public static void main(String[] args)
    {
        int[] values = { 2, 4, 7, 3, 1 };

        printNumbersCounting(values);
        printNumbersRepeated(values);
        printStatusIndicator(values);
        printEqualizer(values);
    }

    private static void printNumbersCounting(int[] values)
    {
        for (int i = 0; i < values.length; i++)
        {
            int value = values[i];
            for (int j = 1; j <= value; j++)
                System.out.print(j);
            System.out.println();
        }
    }
    
    private static void printNumbersRepeated(int[] values)
    {
        for (int i = 0; i < values.length; i++)
        {
            int value = values[i];
            for (int j = 1; j <= value; j++)
                System.out.print(value);
            System.out.println();
        }
    }
    
    private static void printStatusIndicator(int[] values)
    {
        for (int i = 0; i < values.length; i++)
        {
            int value = values[i];

            String indicator = indicatorForValue(value);

            for (int j = 1; j <= value; j++)
                System.out.print(indicator);
            
            System.out.println();
        }
    }

    private static String indicatorForValue(int value)
    {
        String indicator = "-";
        if (value > 2 && value < 6)
            indicator = "=";
        else if (value >= 6)
            indicator = "#";
            
        return indicator;
    }
    
    private static void printEqualizer(int[] values)
    {
        for (int i = 0; i < values.length; i++)
        {
            int value = values[i];

            for (int j = 1; j <= value; j++)
            {
                String indicator = indicatorForValue(j);
                System.out.print(indicator);
            }            
            System.out.println();
        }
    }
}
