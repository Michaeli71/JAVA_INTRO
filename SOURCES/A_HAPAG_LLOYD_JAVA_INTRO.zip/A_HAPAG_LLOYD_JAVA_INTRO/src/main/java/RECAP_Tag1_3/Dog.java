package RECAP_Tag1_3;

import java.util.Objects;

public class Dog
{
    private String breed;
    private int age; 
    private String coatColor;
   
    public Dog(String breed, int age, String coatColor)
    {
        this.breed = breed;
        this.age = age;
        this.coatColor = coatColor;
    }

    public void sleep()
    {
        System.out.println("sleep()");           
    }

    public void eat()
    {
        System.out.println("eat()");                
    }

    public void bark()
    {
        System.out.println("bark()");        
    }

    @Override
    public int hashCode()
    {
        return Objects.hash(age, breed, coatColor);
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Dog other = (Dog) obj;
        return age == other.age && Objects.equals(breed, other.breed) && Objects.equals(coatColor, other.coatColor);
    }

}
