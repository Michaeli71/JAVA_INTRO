package RECAP_Tag1_3;

import java.util.Objects;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public record Ex06_NamedRgbColor(String name, int red, int green, int blue)
{
    public Ex06_NamedRgbColor
    {
        if (red < 0 || red > 255)
            throw new IllegalArgumentException("red value " + red + " is invalid. Must be 0 - 255");
        
        Objects.checkIndex(green, 255);
        Objects.checkIndex(blue, 255);
    }
    
    public static void main(String[] args)
    {
        var myRed = new Ex06_NamedRgbColor("RED", 200, 20, 10);
        System.out.println(myRed);
        
        /*
        var tooRed = new Ex06_NamedRgbColor("TOO RED", 275, 20, 10);
        System.out.println(tooRed);
        */
        var tooGreen = new Ex06_NamedRgbColor("TOO GREEN", 200, 275, 10);
        System.out.println(tooGreen);
    }
}
