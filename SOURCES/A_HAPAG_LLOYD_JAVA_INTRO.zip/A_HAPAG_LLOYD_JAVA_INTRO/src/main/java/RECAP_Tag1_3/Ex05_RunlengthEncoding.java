package RECAP_Tag1_3;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex05_RunlengthEncoding
{
    public static void main(String[] args)
    {
        // Vereinfachung nur Anzahl 1 bis 9
        String input = "A1B2C3D4E5";
        System.out.println(decode(input));
        
        String input2 = "S1U1S1A1N2E1 1I1S2T1 1G1E1R1N1 1L1E2R1D1A1M2E1R1";        
        System.out.println(decode(input2));
        
        System.out.println(encode("ABBCCCDDDDEEEEE"));
        System.out.println(encode("SUSANNE ISST GERN LEERDAMMER"));
        
        // -------------------------------------------
        
        System.out.println(encode("011000111100000111111000000011111111000000000"));
        System.out.println(decode("011203140516071809"));
    }

    private static String decode(String input)
    {        
        String result = "";
        
        for (int i = 0; i < input.length(); i+=2)
        {
            String letter = input.substring(i, i + 1);
            String count = input.substring(i + 1, i + 2);
            
            result += letter.repeat(Integer.parseInt(count));
        }
        
        return result;
    }

    
    private static String encode(String input)
    {        
        String result = "";
        
        String oldLetter = input.substring(0, 1);
        int count = 0;
        
        for (int i = 0; i < input.length(); i++)
        {            
            String letter = input.substring(i, i + 1);
            
            if (oldLetter.equals(letter))
            {
                count++;
            }
            else
            {              
                result += oldLetter + count;
                
                count = 1;  
                oldLetter = letter;
            }
        }
        
        // Ende hinzufügen
        result += oldLetter + count;
        
        return result;
    }
}
