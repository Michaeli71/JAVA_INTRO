package ch06.misc;

import java.util.Collection;
import java.util.HashSet;

import ch06.misc.Spielkarte.Farbe;

public class SpielkartenUsageExample2
{
    public static void main(final String[] args)
    {
        final Collection<Spielkarte> spielkarten = new HashSet<>();
        spielkarten.add(new Spielkarte(Farbe.HERZ, 7));
        
        // PIK 8 einfügen
        spielkarten.add(new Spielkarte(Farbe.PIK, 8));
        spielkarten.add(new Spielkarte(Farbe.KARO, 9));
        
        // Finden wir eine PIK 8?
        final boolean gefunden = spielkarten.contains(new Spielkarte(Farbe.PIK, 8));
        System.out.println("gefunden = " + gefunden);
    }
}
