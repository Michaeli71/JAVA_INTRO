package ch06.misc;

public class ComparingFloatinPoint
{

    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
        double result = 7.2005;
        
        System.out.println(isEqualWithinPrecision(result, 7.2, 0.0007));
        System.out.println(isEqualWithinPrecision(result, 7.2, 0.0001));
    }

    static boolean isEqualWithinPrecision(double calculatedValue, double value, double epsilon)
    {
        return value - epsilon < calculatedValue && calculatedValue < value + epsilon;
    }
}
