package ch06.misc;

import java.util.ArrayList;
import java.util.List;

import ch06.misc.Spielkarte.Farbe;

public class SpielkartenUsageExample1
{
    public static void main(final String[] args)
    {
        // JDK 7: Diamond Operator: ArrayList<> statt ArrayList<Spielkarte>
        final List<Spielkarte> spielkarten = new ArrayList<>();
        
        spielkarten.add(new Spielkarte(Farbe.HERZ, 7)); 
        spielkarten.add(new Spielkarte(Farbe.PIK, 8)); // PIK 8 einfügen
        spielkarten.add(new Spielkarte(Farbe.KARO, 9));
        
        // Finden wir eine PIK 8?
        final boolean gefunden = spielkarten.contains(new Spielkarte(Farbe.PIK, 8));
        System.out.println("gefunden=" + gefunden);
    }
}
