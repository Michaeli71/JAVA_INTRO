package ch06.misc.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex02_PizzaDelivery
{
    public enum PizzaStatus {
        ORDERED,
        PREPARING_TOPPINGS,
        BAKING,
        READY,
        DELIVERED;

        public boolean isInPreparation() {
            return (this == PREPARING_TOPPINGS || this == BAKING);
        } 
        
        public boolean isReadyForDelivery() {
            return (this == READY); 
        }      
    }
    
    public static void main(String[] args)
    {
        System.out.println(PizzaStatus.ORDERED.isReadyForDelivery());
        System.out.println(PizzaStatus.PREPARING_TOPPINGS.isReadyForDelivery());
        System.out.println(PizzaStatus.PREPARING_TOPPINGS.isInPreparation());
        System.out.println(PizzaStatus.READY.isReadyForDelivery());
        System.out.println(PizzaStatus.DELIVERED.isReadyForDelivery());
    }
}
