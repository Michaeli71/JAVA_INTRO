package ch06.misc.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public enum Ex01_Orientation {
    LEFT, CENTER, RIGHT
}
