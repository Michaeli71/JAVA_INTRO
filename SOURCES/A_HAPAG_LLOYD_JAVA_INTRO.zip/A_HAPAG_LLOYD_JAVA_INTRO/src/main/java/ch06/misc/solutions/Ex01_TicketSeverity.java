package ch06.misc.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public enum Ex01_TicketSeverity {
    CRITICAL(10), HIGH(7), MEDIUM(3), LOW(1);

    private final int attentionLevel;

    private Ex01_TicketSeverity(int attentionLevel)
    {
        this.attentionLevel = attentionLevel;
    }

    public int getAttentionLevel()
    {
        return attentionLevel;
    }

    public static void main(String[] args)
    {
        System.out.println("attentionLevel: " + CRITICAL.getAttentionLevel());
        System.out.println("attentionLevel: " + MEDIUM.getAttentionLevel());
    }
}
