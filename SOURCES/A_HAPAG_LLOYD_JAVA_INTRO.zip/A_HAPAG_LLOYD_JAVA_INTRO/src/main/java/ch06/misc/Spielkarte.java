package ch06.misc;

import java.util.Objects;

public final class Spielkarte
{
    enum Farbe {
        KARO, HERZ, PIK, KREUZ
    }

    private final Farbe farbe;

    private final int   wert;

    public Spielkarte(final Farbe farbe, final int wert)
    {
        this.farbe = Objects.requireNonNull(farbe, "farbe must not be null");
        this.wert = wert;
    }

    @Override
    public int hashCode()
    {
        return Objects.hash(farbe, wert);
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Spielkarte other = (Spielkarte) obj;
        return farbe == other.farbe && wert == other.wert;
    }   
}