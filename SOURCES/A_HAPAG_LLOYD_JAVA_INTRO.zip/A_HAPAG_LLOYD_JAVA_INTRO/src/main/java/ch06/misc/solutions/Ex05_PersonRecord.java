package ch06.misc.solutions;

import java.util.ArrayList;
import java.util.List;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex05_PersonRecord
{
    static record Person(String name, int age) {
        public boolean isAdult()
        {
            return age >= 18;
        }
    }
    
    public static void main(String[] args)
    {
        var persons = List.of(new Person("Mike", 37), new Person("Tim", 49),
                              new Person("Tom", 5), new Person("Michael", 50),
                              new Person("Jim", 7), new Person("James", 17));
        
    
        var adults = filterAdults(persons);
        System.out.println("adults: " + adults);
    }

    private static Object filterAdults(List<Person> persons)
    {
        List<Person> adults = new ArrayList<>();
        
        for (Person person : persons)
            if (person.isAdult())
                adults.add(person);
        
        return adults;
    }

}

