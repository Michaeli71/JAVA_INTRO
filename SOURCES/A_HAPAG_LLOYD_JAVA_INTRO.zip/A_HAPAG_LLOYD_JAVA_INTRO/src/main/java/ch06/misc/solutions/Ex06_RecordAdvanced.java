package ch06.misc.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex06_RecordAdvanced
{
    /*
    record Square(double sideLength) {
    }

    record Circle(double radius) {
    }
    */

    public double computeAreaOld(final Object figure) 
    {
        if (figure instanceof Square) 
        {
            final Square square = (Square) figure;
            return square.sideLength * square.sideLength;
        } 
        else if (figure instanceof Circle) 
        {
            final Circle circle = (Circle) figure;
            return circle.radius * circle.radius * Math.PI;
        }
        throw new IllegalArgumentException("figure is not a recognized figure");
    }

    // STEP 1: modernes instanceof ohne CAST
    public double computeAreaV1(final Object figure) 
    {
        if (figure instanceof Square square) 
        {
            return square.sideLength * square.sideLength;
        } 
        else if (figure instanceof Circle circle) 
        {
            return circle.radius * circle.radius * Math.PI;
        }
        throw new IllegalArgumentException("figure is not a recognized figure");
    }
    
    // Step 2:
    interface BaseFigure
    {
        double calcArea();
    }
    
    record Square(double sideLength) implements BaseFigure {

        @Override
        public double calcArea()
        {
            return sideLength * sideLength;
        }
    }

    record Circle(double radius) implements BaseFigure {

        @Override
        public double calcArea()
        {
            return radius * radius * Math.PI;
        }
    }
    
    public double computeAreaV2(final Object figure) 
    {
        if (figure instanceof Square square) 
        {
            return square.calcArea();
        } 
        else if (figure instanceof Circle circle) 
        {
            return circle.calcArea();
        }
        throw new IllegalArgumentException("figure is not a recognized figure");
    }   
    
    // STEP 3:
    
    public double computeAreaV2(final BaseFigure figure) 
    {
        return figure.calcArea();
    }
    
    // BONUS:
    record Rectangle(double width, double height) implements BaseFigure {

        @Override
        public double calcArea()
        {
            return width * height;
        }
    }
}
