package ch06.misc;

import java.util.Objects;

public final class SpielkarteOrig
{
    enum Farbe {
        KARO, HERZ, PIK, KREUZ
    }

    private final Farbe farbe;

    private final int   wert;

    public SpielkarteOrig(final Farbe farbe, final int wert)
    {
        this.farbe = Objects.requireNonNull(farbe, "farbe must not be null");
        this.wert = wert;
    }
}