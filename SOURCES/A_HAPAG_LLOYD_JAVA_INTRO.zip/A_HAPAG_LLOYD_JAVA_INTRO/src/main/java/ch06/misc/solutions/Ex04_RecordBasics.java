package ch06.misc.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex04_RecordBasics
{
/*
 * class Square 
{
    public final double sideLength;

    public Square(final double sideLength) 
    {
        this.sideLength = sideLength;
    }
}

class Circle 
{
    public final double radius;

    public Circle(final double radius) 
    {
        this.radius = radius;
    }
}
 */
    record Square(double sideLength) {}
    record Circle(double radius) {}
    
    
    public static void main(String[] args)
    {
        System.out.println(new Square(42.0));
        System.out.println(new Circle(7.0));
    }
}
