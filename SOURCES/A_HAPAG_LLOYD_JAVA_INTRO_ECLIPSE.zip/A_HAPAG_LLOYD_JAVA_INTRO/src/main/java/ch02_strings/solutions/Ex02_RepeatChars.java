package ch02_strings.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex02_RepeatChars
{   
    public static void main(String[] args)
    {
        System.out.println(repeatChars("ABC"));
        System.out.println(repeatChars("ABCDEF"));
    }

    static String repeatChars(String input)
    {
        String result = "";
        for (int i = 0; i < input.length(); i++)
        {
            char current = input.charAt(i);
            result += ("" + current).repeat(i + 1);
        }
        return result;
    }
}
