package ch02_strings.solutions;

/**
 * Beispielprogramm für das Buch "Einfach Java"
 *
 * (C) 2020 Michael Inden
 */
public class Ex09_StringMerge
{
    static String stringMerge(String input1, String input2)
    {
        int length1 = input1.length();
        int length2 = input2.length();
        
        int maxLen = Math.max(length1, length2);
        
        String result = "";
        for (int i = 0; i < maxLen; i++)
        {
            if (i < length1)
                result += input1.substring(i, i + 1);
            if (i < length2)
                result += input2.substring(i, i + 1);
        }
        return result;
    }
    
    public static void main(String[] args)
    {       
        System.out.println(stringMerge("ACE", "BDFGHI"));
        System.out.println(stringMerge("", "ABC"));
        System.out.println(stringMerge("ABC", "")); 
        System.out.println(stringMerge("ACE", "BDF"));     

    }
}
