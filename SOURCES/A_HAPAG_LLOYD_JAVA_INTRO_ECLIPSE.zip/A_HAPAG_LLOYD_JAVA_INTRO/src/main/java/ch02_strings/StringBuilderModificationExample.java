package ch02_strings;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class StringBuilderModificationExample
{
    public static void main(String[] args)
    {
        StringBuilder sb = new StringBuilder("This is Mava");
        
        sb.setCharAt(8, 'J');
        
        System.out.println(sb.toString());
        
        // Weitere Möglichkeiten
        // StringBuffer => StringBuilder
        StringBuilder sb2 = new StringBuilder("Dies IST ein Test");
        sb2.delete(5, 8);
        sb2.replace(6, 9, "----------");
        System.out.println(sb2.toString());
    }
}
