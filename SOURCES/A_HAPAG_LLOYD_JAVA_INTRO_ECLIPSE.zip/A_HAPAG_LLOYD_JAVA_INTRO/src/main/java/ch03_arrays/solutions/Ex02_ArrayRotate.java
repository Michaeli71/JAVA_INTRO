package ch03_arrays.solutions;

import java.util.Arrays;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex02_ArrayRotate
{
    public static void main(String[] args)
    {
        int[] values = { 1, 2, 3, 4, 5, 6, 7 };
        rotateRight(values);
        rotateRight(values);
        System.out.println(Arrays.toString(values));
        rotateRight(values);
        rotateRight(values);
        System.out.println(Arrays.toString(values));
        
        rotateLeft(values);
        System.out.println(Arrays.toString(values));
        rotateLeft(values);
        System.out.println(Arrays.toString(values));
    }

    static void rotateRight(final int[] values)
    {
        if (values.length < 2)
            return;

        // merke den letzten Wert in temp 
        final int endPos = values.length - 1;
        final int temp = values[endPos];
        
        // rüberkopieren
        for (int i = endPos; i > 0; i--)
            values[i] = values[i - 1];

        values[0] = temp;
    }

    static void rotateLeft(final int[] values)
    {
        if (values.length < 2)
            return;
        
        final int endPos = values.length - 1;
        final int temp = values[0];
        
        for (int i = 0; i < endPos; i++)
            values[i] = values[i + 1];
        
        values[endPos] = temp;
    }

}
