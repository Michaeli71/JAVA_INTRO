package ch03_arrays.solutions;

import java.util.Arrays;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex10_Arrays
{
    public static void main(final String[] args)
    {
        final byte[] string1 = "ABC-DEF-GHI".getBytes();
        final byte[] string2 = "DEF".getBytes();
        System.out.println(Arrays.compare(string1, string2));
        System.out.println(Arrays.compare(string1, 4, 7, string2, 0, 3));
        System.out.println(Arrays.compare(string1, 8, 11, string2, 0, 3));

        final byte[] first = "ABCDEFGHIJK".getBytes();
        final byte[] second = "XYZABCDEXYZ".getBytes();

        System.out.println("compare: " + Arrays.compare(first, second));

        for (int i = 0; i < Math.min(first.length, second.length); i++)
        {
            final int maxLength = Math.min(first.length, second.length);

            System.out.println("Comparing: " + new String(Arrays.copyOfRange(first, i, maxLength)) + " and "
                               + new String(Arrays.copyOfRange(second, i, maxLength)));

            System.out.println("compare from " + i + " to " + (maxLength) + " - result: "
                               + Arrays.compare(first, i, maxLength, second, i, maxLength));
        }
    }
}
