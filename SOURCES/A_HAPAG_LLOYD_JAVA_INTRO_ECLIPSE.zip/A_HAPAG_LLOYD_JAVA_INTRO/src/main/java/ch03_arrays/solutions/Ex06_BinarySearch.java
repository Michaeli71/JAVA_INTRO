package ch03_arrays.solutions;

import java.util.Arrays;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex06_BinarySearch
{
    public static void main(String[] args)
    {
        int[] values = { 2, 3, 5, 7, 11, 13};

        boolean pos = binarySearch(values, 7);
        System.out.println("found at: " + pos);
        
        boolean pos0 = binarySearch(values, 0);
        System.out.println("found at: " + pos0);
        
        boolean pos13 = binarySearch(values, 13);
        System.out.println("found at: " + pos13);
    }

    private static boolean binarySearch(int[] values, int desiredValue)
    {
        if (values.length == 0)
            return false;
        
        int midPos = (values.length - 1) / 2;
        
        if (desiredValue == values[midPos])
            return true;
        
        if (desiredValue > values[midPos])
        {            
            int[] upperPart = Arrays.copyOfRange(values, midPos + 1, values.length);
            return binarySearch(upperPart, desiredValue);
        }
        else
        {
            int[] lowerPart = Arrays.copyOfRange(values, 0, midPos);
            return binarySearch(lowerPart, desiredValue);
        }
    }
}
