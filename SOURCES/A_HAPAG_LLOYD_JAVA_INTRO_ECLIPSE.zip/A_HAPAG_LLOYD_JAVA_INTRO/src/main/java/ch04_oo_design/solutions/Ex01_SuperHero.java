package ch04_oo_design.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex01_SuperHero
{
    public static void main(String[] args)
    {
        SuperHero superMan = new SuperHero("Superman", "Kryptonite-Power", 1_000);
        SuperHero batMan = new SuperHero("Batman", "Techno-Power", 100);
        SuperHero ironMan = new SuperHero("Ironman", "Techno-Power", 500);
        System.out.println("Superman stronger than Batman? " + superMan.isStrongerThan(batMan));
        System.out.println(SuperHero.strongestOf(superMan, batMan, ironMan));
    }
}
