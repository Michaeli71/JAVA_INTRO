package ch04_oo_design.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class SuperHero
{
    private final String name;

    private final String superPower;

    private int          strength;

    public SuperHero(String name, String superPower, int strength)
    {
        this.name = name;
        this.superPower = superPower;
        this.strength = strength;
    }

    private String getName()
    {
        return name;
    }

    public String getSuperPower()
    {
        return superPower;
    }

    public int getStrength()
    {
        return strength;
    }

    public void setStrength(int newStrength)
    {
        this.strength = newStrength;
    }

    @Override
    public String toString()
    {
        return name + " has " + superPower + " and strength: " + strength;
    }

    public boolean isStrongerThan(SuperHero other)
    {
        return strength > other.strength;
    }

    public static SuperHero strongestOf(SuperHero... heros)
    {
        SuperHero strongestHero = null;
        for (SuperHero hero : heros)
        {
            if (strongestHero == null || hero.isStrongerThan(strongestHero))
            {
                strongestHero = hero;
            }
        }
        return strongestHero;
    }
}