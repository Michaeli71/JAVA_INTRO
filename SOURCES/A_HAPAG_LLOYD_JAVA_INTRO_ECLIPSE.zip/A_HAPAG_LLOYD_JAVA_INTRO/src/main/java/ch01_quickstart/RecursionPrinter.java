package ch01_quickstart;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class RecursionPrinter
{
    public static void main(String[] args)
    {
        recursivePrint(4);
    }

    private static void recursivePrint(int n)
    {
        // rekursiver Abbruch
        if (n < 1)
            return;
        
        if (n==1)
            System.out.println("-");
        else
        {
            recursivePrint(n-1);
            System.out.println("=".repeat(n));
            recursivePrint(n-1);
        }
    }
}
