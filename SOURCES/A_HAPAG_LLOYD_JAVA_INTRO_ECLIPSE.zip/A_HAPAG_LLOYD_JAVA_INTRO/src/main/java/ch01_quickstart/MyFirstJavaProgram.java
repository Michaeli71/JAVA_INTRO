package ch01_quickstart;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class MyFirstJavaProgram
{
    public static void main(String[] args)
    {
        System.out.println("Hello World");
    }
}
