package ch01_quickstart;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class RekursionExample
{
    public static void main(String[] args)
    {
        printCountDownRec(5);
    }
    
    static void printCountDownRec(int value)
    {
        // rekursiver Abbruch
        if (value < 0)
        {
            System.out.println("FINISH");
            return;
        }
        
        System.out.println(value);
        
        // rekursiver Abstieg
        printCountDownRec(value - 1);
    }
}
