package ch01_quickstart.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex09_Fakultaet
{
    public static void main(String[] args)
    {
        for (int value = 1; value < 10; value++)
        {
            int result = fakultaet(value);
            System.out.println("Fakultät von " + value + " = " + result);
        }
    }

    private static int fakultaet(int value)
    {
        // rekursiver Abbruch
        if (value == 0 || value == 1)
            return 1;

        // rekursiver Abstieg
        return value * fakultaet(value - 1);
    }    
}
