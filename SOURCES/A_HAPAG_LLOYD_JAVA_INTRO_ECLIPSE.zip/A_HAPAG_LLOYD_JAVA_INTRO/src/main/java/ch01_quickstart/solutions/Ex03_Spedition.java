package ch01_quickstart.solutions;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class Ex03_Spedition
{
    public static void main(String[] args)
    {
        int bestellmenge = 2222;
        int lkw_kapazität = 75;

        int anzahl_fahrten = bestellmenge / lkw_kapazität;
        int restmenge_letzte_fahrt = bestellmenge % lkw_kapazität;
        if (restmenge_letzte_fahrt != 0)            
            anzahl_fahrten++;

        System.out.println("Restmenge: " + restmenge_letzte_fahrt);
        System.out.println("Wir benötigen " + anzahl_fahrten + " Fahrten");
        
        berechne_fahrten(1000, 100);
        berechne_fahrten(1050, 100);
        
        for (int bestellung = 1000; bestellung < 2000; bestellung += 150)
        {
            berechne_fahrten(bestellung, 77);
        }
    }

    private static void berechne_fahrten(int bestellmenge, int lkw_kapazität)
    {
        int anzahl_fahrten = bestellmenge / lkw_kapazität;
        int restmenge_letzte_fahrt = bestellmenge % lkw_kapazität;
        if (restmenge_letzte_fahrt != 0)            
            anzahl_fahrten++;

        System.out.println("Restmenge: " + restmenge_letzte_fahrt);
        System.out.println("Wir benötigen " + anzahl_fahrten + " Fahrten");
    }
}
