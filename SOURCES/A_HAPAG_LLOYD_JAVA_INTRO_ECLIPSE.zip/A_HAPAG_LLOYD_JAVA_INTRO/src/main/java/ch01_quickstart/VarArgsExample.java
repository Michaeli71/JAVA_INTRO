package ch01_quickstart;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class VarArgsExample
{
    public static void main(String[] args)
    {
        System.out.println(var_args_sum("Summe: ", 1, 2, 3, 4, 5, 6, 7));
    }
    
    static String var_args_sum(String info, int... args)
    {
        int result = 0;
        for (int num : args)
            result += num;
    
        return info + String.valueOf(result);
    }
}